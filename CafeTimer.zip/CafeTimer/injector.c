/*
 * injector.c
 *
 * Minimal DLL injector. Waits for a process matching TARGET_EXE to appear,
 * then injects hook.dll into it using the classic
 * CreateRemoteThread + LoadLibraryA technique.
 *
 * Build (from an MSYS2/MinGW-w64 shell on Windows, or cross-compiled on Linux):
 *   gcc injector.c -o injector.exe -lpsapi
 *
 * Usage:
 *   injector.exe <target_exe_name> <full_path_to_hook.dll>
 *   e.g. injector.exe generalszh.exe C:\cafetimer\hook32.dll
 */

#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "inject_core.h"   /* shared VirtualAllocEx + CreateRemoteThread injector */

static DWORD FindProcessId(const char *exeName) {
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;

    DWORD pid = 0;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, exeName) == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <target_exe_name> <full_path_to_hook.dll>\n", argv[0]);
        printf("Example: %s generalszh.exe C:\\cafetimer\\hook32.dll\n", argv[0]);
        return 1;
    }

    const char *targetExe = argv[1];
    const char *dllPath = argv[2];

    printf("[*] Waiting for process: %s\n", targetExe);

    DWORD pid = 0;
    /* Poll for up to 60 seconds for the game to appear */
    for (int i = 0; i < 60 && pid == 0; i++) {
        pid = FindProcessId(targetExe);
        if (pid == 0) Sleep(1000);
    }

    if (pid == 0) {
        printf("[!] Timed out waiting for %s\n", targetExe);
        return 1;
    }

    printf("[+] Found %s with PID %lu\n", targetExe, pid);

    /* Give the process a moment to finish its own early init before we inject */
    Sleep(1500);

    char err[256];
    int code = InjectDllIntoPid(pid, dllPath, err, sizeof(err));
    if (code != 0) {
        printf("[!] %s\n", err);
        if (code == 3) printf("    (try running injector.exe as Administrator)\n");
        if (code == 8) printf("    (almost always a 32/64-bit mismatch between hook.dll and the target)\n");
        return code;
    }

    printf("[+] Injected. Done.\n");
    return 0;
}
