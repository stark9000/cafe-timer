Cafe Timer - Java control side (minimal)
========================================

Just enough Java to talk to TimerService.exe's discovery + control
protocol, so you can test a station or drive it from your own tooling.
Plain JDK, Java 8, no dependencies.

Files (java/src):
  CafeTimerClient.java  - networking core + a command-line tool
  CafeTimerUI.java      - optional minimal Swing control panel
  ProtocolTest.java     - headless self-test: an in-process mock of the
                          TimerService protocol + assertions (no Windows
                          service needed). 20 checks.
  ScreenshotDriver.java - test tooling that drives CafeTimerUI against the
                          mock to capture documentation screenshots.

Build:
  javac -d out src/CafeTimerClient.java src/CafeTimerUI.java src/ProtocolTest.java
  (or just open src/ in NetBeans as a Java application)

Run the self-test (proves the client speaks the protocol correctly):
  java -cp out ProtocolTest
  -> prints PASS/FAIL per check, exit 0 if all pass.

Command-line use against a real station:
  java -cp out CafeTimerClient discover
  java -cp out CafeTimerClient send <ip> --token <tok> START_SESSION 60
  java -cp out CafeTimerClient status <ip>

Optional GUI:
  java -cp out CafeTimerUI                      (broadcast discovery)
  java -cp out CafeTimerUI 192.168.1.255 secret (broadcast addr + token)
  The Broadcast field also accepts a comma-separated list of specific IPs
  for networks where broadcast is blocked.

Note: ProtocolTest and ScreenshotDriver are test/tooling only - the shipped
"Java side" is really just CafeTimerClient (+ the optional CafeTimerUI).
