/*
 * CafeTimerClient.java
 *
 * Minimal Java side for the Cafe Timer system - just enough to talk to
 * TimerService.exe's UDP discovery and TCP control server so you can
 * exercise a station from the command line (or drive it from your own
 * UI later). No GUI, no dependencies - plain JDK sockets, Java 8.
 *
 * Wire protocol (must match TimerService.c):
 *   Discovery (UDP 47100): send  "TIMERCAFE_DISCOVER_V1" (broadcast)
 *                          reply "TIMERCAFE_HERE_V1|<hostname>|<ctrlPort>"
 *   Control   (TCP 47200): one command per line, one reply line each:
 *       AUTH <token> | GET_STATUS | START_SESSION <min> | EXTEND <min>
 *       PAUSE | RESUME | STOP
 *     replies: "OK" | "ERR <reason>" | "STATUS <RUNNING|PAUSED|STOPPED> <sec>"
 *   GET_STATUS is always allowed; state-changing commands need a prior
 *   AUTH on the same connection when the station has a control token set.
 *
 * Build: javac CafeTimerClient.java
 * Use:
 *   java CafeTimerClient discover [broadcastAddr]
 *   java CafeTimerClient send <ip> [--port N] [--token T] <command...>
 *   java CafeTimerClient status <ip> [--port N]
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CafeTimerClient {

    public static final int    DISCOVERY_PORT = 47100;
    public static final int    CONTROL_PORT   = 47200;
    public static final String REQ_MAGIC      = "TIMERCAFE_DISCOVER_V1";
    public static final String REPLY_MAGIC    = "TIMERCAFE_HERE_V1";

    /** A discovered station. */
    public static final class Station {
        public final String host, ip;
        public final int port;
        public Station(String host, String ip, int port) { this.host = host; this.ip = ip; this.port = port; }
        public String toString() { return host + " (" + ip + ":" + port + ")"; }
    }

    /**
     * Broadcasts a discovery request and collects replies for up to
     * timeoutMs. target is usually "255.255.255.255" (LAN broadcast); pass
     * a specific address to probe one host. De-duplicated by IP.
     */
    public static List<Station> discover(String target, int timeoutMs) throws IOException {
        Map<String, Station> byIp = new LinkedHashMap<String, Station>();
        DatagramSocket sock = new DatagramSocket();
        try {
            sock.setBroadcast(true);
            byte[] req = REQ_MAGIC.getBytes("US-ASCII");
            sock.send(new DatagramPacket(req, req.length, InetAddress.getByName(target), DISCOVERY_PORT));

            long deadline = System.currentTimeMillis() + timeoutMs;
            byte[] buf = new byte[512];
            while (true) {
                int remaining = (int) (deadline - System.currentTimeMillis());
                if (remaining <= 0) break;
                sock.setSoTimeout(remaining);
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try {
                    sock.receive(p);
                } catch (SocketTimeoutException e) {
                    break;
                }
                String msg = new String(p.getData(), 0, p.getLength(), "US-ASCII");
                if (!msg.startsWith(REPLY_MAGIC + "|")) continue;
                String[] parts = msg.split("\\|");
                if (parts.length < 3) continue;
                String ip = p.getAddress().getHostAddress();
                int port;
                try { port = Integer.parseInt(parts[2].trim()); } catch (NumberFormatException e) { continue; }
                byIp.put(ip, new Station(parts[1], ip, port));
            }
        } finally {
            sock.close();
        }
        return new ArrayList<Station>(byIp.values());
    }

    /**
     * Opens one connection, sends each command line in order, and returns
     * the one reply line for each (nulls if the peer closed early).
     */
    public static String[] exchange(String ip, int port, String[] commands, int timeoutMs) throws IOException {
        Socket sock = new Socket();
        try {
            sock.connect(new InetSocketAddress(ip, port), timeoutMs);
            sock.setSoTimeout(timeoutMs);
            OutputStream out = sock.getOutputStream();
            InputStream in = sock.getInputStream();
            String[] replies = new String[commands.length];
            for (int i = 0; i < commands.length; i++) {
                out.write((commands[i] + "\n").getBytes("US-ASCII"));
                out.flush();
                replies[i] = readLine(in);
            }
            return replies;
        } finally {
            sock.close();
        }
    }

    /** Convenience: AUTH (if token given) then one command; returns its reply. */
    public static String command(String ip, int port, String token, String command, int timeoutMs)
            throws IOException {
        String[] cmds;
        if (token != null && !token.isEmpty()) {
            cmds = new String[] { "AUTH " + token, command };
        } else {
            cmds = new String[] { command };
        }
        String[] r = exchange(ip, port, cmds, timeoutMs);
        return r[r.length - 1];
    }

    /** Reads one '\n'-terminated line (stripping '\r'); null on EOF with no data. */
    public static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        boolean any = false;
        while ((c = in.read()) != -1) {
            any = true;
            if (c == '\n') break;
            if (c == '\r') continue;
            sb.append((char) c);
        }
        if (!any && sb.length() == 0) return null;
        return sb.toString();
    }

    /* --------------------------- CLI --------------------------- */

    public static void main(String[] args) throws Exception {
        if (args.length == 0) { usage(); return; }

        if (args[0].equals("discover")) {
            String target = args.length > 1 ? args[1] : "255.255.255.255";
            System.out.println("Discovering on " + target + ":" + DISCOVERY_PORT + " ...");
            List<Station> found = discover(target, 1500);
            if (found.isEmpty()) {
                System.out.println("(no stations replied)");
            } else {
                for (Station s : found) System.out.println("  " + s);
            }
            return;
        }

        if (args[0].equals("send") || args[0].equals("status")) {
            if (args.length < 2) { usage(); return; }
            String ip = args[1];
            int port = CONTROL_PORT;
            String token = null;
            List<String> rest = new ArrayList<String>();
            for (int i = 2; i < args.length; i++) {
                if (args[i].equals("--port") && i + 1 < args.length) { port = Integer.parseInt(args[++i]); }
                else if (args[i].equals("--token") && i + 1 < args.length) { token = args[++i]; }
                else rest.add(args[i]);
            }
            String cmd;
            if (args[0].equals("status")) {
                cmd = "GET_STATUS";
            } else {
                if (rest.isEmpty()) { usage(); return; }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < rest.size(); i++) { if (i > 0) sb.append(' '); sb.append(rest.get(i)); }
                cmd = sb.toString();
            }
            try {
                System.out.println(command(ip, port, token, cmd, 3000));
            } catch (IOException e) {
                System.out.println("ERR could not reach " + ip + ":" + port + " (" + e.getMessage() + ")");
            }
            return;
        }

        usage();
    }

    private static void usage() {
        System.out.println("Cafe Timer control client");
        System.out.println("  java CafeTimerClient discover [broadcastAddr]");
        System.out.println("  java CafeTimerClient send <ip> [--port N] [--token T] <command...>");
        System.out.println("  java CafeTimerClient status <ip> [--port N]");
        System.out.println("Examples:");
        System.out.println("  java CafeTimerClient discover");
        System.out.println("  java CafeTimerClient send 192.168.1.50 --token secret START_SESSION 60");
        System.out.println("  java CafeTimerClient status 192.168.1.50");
    }
}
