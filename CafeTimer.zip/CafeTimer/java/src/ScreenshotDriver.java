/*
 * ScreenshotDriver.java  (test/tooling only - not part of the shipped app)
 *
 * Runs the real CafeTimerUI against two in-process MockStations (which
 * speak TimerService's exact protocol) and captures PNG screenshots of the
 * UI in several states. Used to produce documentation images headlessly
 * under Xvfb; not needed to build or run the actual system.
 *
 * Run: java ScreenshotDriver <outputDir>
 */

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class ScreenshotDriver {

    public static void main(String[] args) throws Exception {
        String outDir = args.length > 0 ? args[0] : "shots";
        new File(outDir).mkdirs();

        // Two stations on distinct loopback IPs, both requiring token "secret".
        ProtocolTest.MockStation s1 =
                new ProtocolTest.MockStation("secret", "CAFE-PC-01", "127.0.0.2", 47100, 47200);
        ProtocolTest.MockStation s2 =
                new ProtocolTest.MockStation("secret", "CAFE-PC-02", "127.0.0.3", 47100, 47200);
        s1.start();
        s2.start();
        Thread.sleep(250);

        try { UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel"); } catch (Exception ignored) {}

        final CafeTimerUI[] holder = new CafeTimerUI[1];
        SwingUtilities.invokeAndWait(() -> {
            CafeTimerUI ui = new CafeTimerUI("127.0.0.2, 127.0.0.3", "secret");
            ui.setVisible(true);
            holder[0] = ui;
        });
        CafeTimerUI ui = holder[0];
        Thread.sleep(600);
        Robot robot = new Robot();

        shot(robot, ui, outDir, "01_startup");

        ui.discoverNow();
        ui.refreshNow();
        Thread.sleep(500);
        shot(robot, ui, outDir, "02_discovered");

        ui.selectRow(0);
        Thread.sleep(200);
        ui.sendSelected("START_SESSION 60");
        Thread.sleep(400);
        ui.refreshNow();
        Thread.sleep(300);
        shot(robot, ui, outDir, "03_session_running");

        ui.sendSelected("PAUSE");
        Thread.sleep(300);
        ui.refreshNow();
        Thread.sleep(300);
        shot(robot, ui, outDir, "04_paused");

        ui.sendSelected("RESUME");
        Thread.sleep(150);
        ui.sendSelected("EXTEND 30");
        Thread.sleep(200);
        ui.selectRow(1);
        Thread.sleep(150);
        ui.sendSelected("START_SESSION 120");
        Thread.sleep(400);
        ui.refreshNow();
        Thread.sleep(300);
        shot(robot, ui, outDir, "05_two_stations_running");

        ui.selectRow(0);
        Thread.sleep(150);
        ui.sendSelected("STOP");
        Thread.sleep(300);
        ui.refreshNow();
        Thread.sleep(300);
        shot(robot, ui, outDir, "06_one_stopped_one_running");

        s1.stop();
        s2.stop();
        System.out.println("screenshots written to " + outDir);
        System.exit(0);
    }

    static void shot(Robot robot, JFrame f, String outDir, String name) throws Exception {
        final Rectangle[] b = new Rectangle[1];
        SwingUtilities.invokeAndWait(() -> b[0] = f.getBounds());
        BufferedImage img = robot.createScreenCapture(b[0]);
        File out = new File(outDir, name + ".png");
        ImageIO.write(img, "png", out);
        System.out.println("  captured " + out.getName());
    }
}
