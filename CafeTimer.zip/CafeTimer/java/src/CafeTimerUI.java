/*
 * CafeTimerUI.java
 *
 * Minimal Swing control panel for the Cafe Timer system. Discovers
 * stations (TimerService.exe instances) on the LAN, shows each one's live
 * session state, and sends control commands. Pure JDK Swing, Java 8 - no
 * dependencies. This is the optional GUI; CafeTimerClient is usable on its
 * own from the command line.
 *
 * Build: javac CafeTimerClient.java CafeTimerUI.java
 * Run:   java CafeTimerUI
 */

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CafeTimerUI extends JFrame {

    private final DefaultTableModel model;
    private final JTable table;
    private final JTextField targetField, tokenField, minutesField;
    private final JLabel statusLabel;

    public CafeTimerUI(String discoverTarget, String token) {
        super("Cafe Timer \u2014 Control");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        model = new DefaultTableModel(new Object[]{"Host", "IP", "Port", "State", "Remaining"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(140);
        table.getColumnModel().getColumn(3).setPreferredWidth(90);
        table.getColumnModel().getColumn(4).setPreferredWidth(90);

        // --- top toolbar ---
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        targetField = new JTextField(discoverTarget, 14);
        tokenField  = new JTextField(token, 10);
        JButton discoverBtn = new JButton("Discover");
        discoverBtn.addActionListener(e -> runBg(this::discoverNow));
        top.add(new JLabel("Broadcast:"));
        top.add(targetField);
        top.add(discoverBtn);
        top.add(Box.createHorizontalStrut(12));
        top.add(new JLabel("Token:"));
        top.add(tokenField);

        // --- bottom controls ---
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        minutesField = new JTextField("60", 4);
        JButton start  = new JButton("Start");
        JButton extend = new JButton("Extend");
        JButton pause  = new JButton("Pause");
        JButton resume = new JButton("Resume");
        JButton stop   = new JButton("Stop");
        start.addActionListener(e  -> runBg(() -> sendSelected("START_SESSION " + minutes())));
        extend.addActionListener(e -> runBg(() -> sendSelected("EXTEND " + minutes())));
        pause.addActionListener(e  -> runBg(() -> sendSelected("PAUSE")));
        resume.addActionListener(e -> runBg(() -> sendSelected("RESUME")));
        stop.addActionListener(e   -> runBg(() -> sendSelected("STOP")));
        bottom.add(new JLabel("Minutes:"));
        bottom.add(minutesField);
        bottom.add(start);
        bottom.add(extend);
        bottom.add(pause);
        bottom.add(resume);
        bottom.add(stop);

        statusLabel = new JLabel("Ready. Click Discover to find stations.");
        statusLabel.setBorder(new EmptyBorder(6, 10, 8, 10));

        JPanel south = new JPanel(new BorderLayout());
        south.add(bottom, BorderLayout.CENTER);
        south.add(statusLabel, BorderLayout.SOUTH);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder("Stations"));

        JPanel root = new JPanel(new BorderLayout());
        root.setBorder(new EmptyBorder(4, 4, 4, 4));
        root.add(top, BorderLayout.NORTH);
        root.add(sp, BorderLayout.CENTER);
        root.add(south, BorderLayout.SOUTH);
        setContentPane(root);
        setSize(620, 360);
        setLocation(0, 0);

        // poll live status once a second
        new javax.swing.Timer(1000, e -> runBg(this::refreshNow)).start();
    }

    private int minutes() {
        try { return Integer.parseInt(minutesField.getText().trim()); }
        catch (NumberFormatException e) { return 0; }
    }

    private static void runBg(Runnable r) { new Thread(r).start(); }

    private void setStatus(String s) { SwingUtilities.invokeLater(() -> statusLabel.setText(s)); }

    /* ---- network actions (run off the EDT) ---- */

    void discoverNow() {
        String raw = targetField.getText().trim();
        setStatus("Discovering on " + raw + " ...");
        // Broadcast address, or a comma-separated list of specific IPs for
        // networks where broadcast is blocked.
        Map<String, CafeTimerClient.Station> merged = new LinkedHashMap<String, CafeTimerClient.Station>();
        try {
            for (String t : raw.split(",")) {
                t = t.trim();
                if (t.isEmpty()) continue;
                for (CafeTimerClient.Station s : CafeTimerClient.discover(t, 1200))
                    merged.put(s.ip, s);
            }
            final List<CafeTimerClient.Station> found = new java.util.ArrayList<CafeTimerClient.Station>(merged.values());
            SwingUtilities.invokeLater(() -> {
                model.setRowCount(0);
                for (CafeTimerClient.Station s : found)
                    model.addRow(new Object[]{s.host, s.ip, s.port, "?", "?"});
            });
            setStatus(found.isEmpty() ? "No stations replied." : "Found " + found.size() + " station(s).");
        } catch (Exception e) {
            setStatus("Discovery failed: " + e.getMessage());
        }
    }

    void refreshNow() {
        for (int row = 0; row < model.getRowCount(); row++) {
            String ip = (String) model.getValueAt(row, 1);
            int port = (Integer) model.getValueAt(row, 2);
            final int r = row;
            try {
                String reply = CafeTimerClient.command(ip, port, null, "GET_STATUS", 1500);
                String[] p = reply == null ? new String[0] : reply.split(" ");
                final String state = (p.length == 3) ? p[1] : "?";
                final String rem   = (p.length == 3) ? fmt(p[2]) : "?";
                SwingUtilities.invokeLater(() -> {
                    if (r < model.getRowCount()) { model.setValueAt(state, r, 3); model.setValueAt(rem, r, 4); }
                });
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    if (r < model.getRowCount()) { model.setValueAt("unreachable", r, 3); model.setValueAt("-", r, 4); }
                });
            }
        }
    }

    void sendSelected(String command) {
        int row = table.getSelectedRow();
        if (row < 0) { setStatus("Select a station first."); return; }
        String ip = (String) model.getValueAt(row, 1);
        int port = (Integer) model.getValueAt(row, 2);
        String token = tokenField.getText().trim();
        try {
            String reply = CafeTimerClient.command(ip, port, token, command, 2000);
            setStatus(command + "  \u2192  " + reply);
            refreshNow();
        } catch (Exception e) {
            setStatus(command + " failed: " + e.getMessage());
        }
    }

    void selectRow(int r) { SwingUtilities.invokeLater(() -> { if (r < model.getRowCount()) table.setRowSelectionInterval(r, r); }); }

    private static String fmt(String secStr) {
        try {
            long s = Long.parseLong(secStr);
            return String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        } catch (NumberFormatException e) { return secStr; }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel"); } catch (Exception ignored) {}
        String target = args.length > 0 ? args[0] : "255.255.255.255";
        String token  = args.length > 1 ? args[1] : "";
        SwingUtilities.invokeLater(() -> new CafeTimerUI(target, token).setVisible(true));
    }
}
