/*
 * ProtocolTest.java
 *
 * Headless self-test for CafeTimerClient. Since TimerService.exe is a
 * Windows service and can't run here, this spins up a small in-process
 * MockStation that re-implements the exact wire protocol from
 * TimerService.c (UDP discovery + the TCP control state machine, auth
 * gating, and the 1..100000 minute bounds), then drives CafeTimerClient
 * against it and asserts every reply.
 *
 * Build: javac CafeTimerClient.java ProtocolTest.java
 * Run:   java ProtocolTest
 * Exit code 0 = all passed, 1 = something failed.
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class ProtocolTest {

    static int passed = 0, failed = 0;

    static void check(String name, boolean cond, String detail) {
        if (cond) { passed++; System.out.println("  PASS  " + name); }
        else { failed++; System.out.println("  FAIL  " + name + "   -> " + detail); }
    }

    public static void main(String[] args) throws Exception {
        MockStation mock = new MockStation("secret", "TEST-PC", 47100, 47200);
        mock.start();
        Thread.sleep(250); // let the sockets bind

        final String ip = "127.0.0.1";
        final int port = 47200;

        System.out.println("Cafe Timer protocol test (client <-> mock station)\n");

        // --- discovery (loopback target so it doesn't depend on broadcast) ---
        List<CafeTimerClient.Station> found = CafeTimerClient.discover("127.0.0.1", 1500);
        check("discovery finds the station", found.size() == 1, "size=" + found.size());
        if (found.size() == 1) {
            CafeTimerClient.Station s = found.get(0);
            check("discovery reports hostname", "TEST-PC".equals(s.host), "host=" + s.host);
            check("discovery reports control port", s.port == 47200, "port=" + s.port);
        }

        // --- auth gating ---
        check("state change without AUTH is refused",
                eq(send(ip, port, "START_SESSION 15"), "ERR auth required"),
                last(send(ip, port, "START_SESSION 15")));
        check("wrong token refused",
                eq(send(ip, port, "AUTH nope"), "ERR bad token"),
                last(send(ip, port, "AUTH nope")));

        // --- start a session ---
        String[] r = send(ip, port, "AUTH secret", "START_SESSION 15");
        check("AUTH ok", eq1(r, 0, "OK"), r[0]);
        check("START_SESSION ok", eq1(r, 1, "OK"), r[1]);

        // GET_STATUS is open (no auth needed)
        String st = send(ip, port, "GET_STATUS")[0];
        check("GET_STATUS RUNNING ~900s", statusIs(st, "RUNNING", 895, 900), st);

        // --- pause / resume ---
        check("PAUSE ok", eq(send(ip, port, "AUTH secret", "PAUSE"), "OK"), last(send(ip, port, "AUTH secret", "PAUSE")));
        st = send(ip, port, "GET_STATUS")[0];
        check("status PAUSED after pause", statusIs(st, "PAUSED", 890, 900), st);
        check("RESUME ok", eq(send(ip, port, "AUTH secret", "RESUME"), "OK"), "");
        st = send(ip, port, "GET_STATUS")[0];
        check("status RUNNING after resume", statusIs(st, "RUNNING", 885, 900), st);

        // --- extend ---
        check("EXTEND ok", eq(send(ip, port, "AUTH secret", "EXTEND 5"), "OK"), "");
        st = send(ip, port, "GET_STATUS")[0];
        check("remaining grew by ~5 min after EXTEND", statusIs(st, "RUNNING", 1180, 1200), st);

        // --- bounds ---
        check("START_SESSION 0 rejected",
                startsWith(send(ip, port, "AUTH secret", "START_SESSION 0"), "ERR minutes out of range"),
                last(send(ip, port, "AUTH secret", "START_SESSION 0")));
        check("START_SESSION -5 rejected",
                startsWith(send(ip, port, "AUTH secret", "START_SESSION -5"), "ERR minutes out of range"),
                last(send(ip, port, "AUTH secret", "START_SESSION -5")));
        check("START_SESSION 200000 rejected",
                startsWith(send(ip, port, "AUTH secret", "START_SESSION 200000"), "ERR minutes out of range"),
                last(send(ip, port, "AUTH secret", "START_SESSION 200000")));

        // --- unknown command ---
        check("unknown command rejected",
                eq(send(ip, port, "AUTH secret", "FROBNICATE"), "ERR unknown command"),
                last(send(ip, port, "AUTH secret", "FROBNICATE")));

        // --- stop ---
        check("STOP ok", eq(send(ip, port, "AUTH secret", "STOP"), "OK"), "");
        st = send(ip, port, "GET_STATUS")[0];
        check("status STOPPED after stop", statusIs(st, "STOPPED", 0, 0), st);

        mock.stop();

        System.out.println("\n" + passed + " passed, " + failed + " failed.");
        System.exit(failed == 0 ? 0 : 1);
    }

    /* ---- helpers ---- */

    static String[] send(String ip, int port, String... cmds) {
        try { return CafeTimerClient.exchange(ip, port, cmds, 3000); }
        catch (IOException e) { return new String[] { "ERR io " + e.getMessage() }; }
    }
    static boolean eq(String[] r, String want) { return r.length > 0 && want.equals(r[r.length - 1]); }
    static boolean eq1(String[] r, int i, String want) { return i < r.length && want.equals(r[i]); }
    static boolean startsWith(String[] r, String pfx) { return r.length > 0 && r[r.length - 1] != null && r[r.length - 1].startsWith(pfx); }
    static String last(String[] r) { return r.length > 0 ? r[r.length - 1] : "(no reply)"; }

    static boolean statusIs(String line, String state, int loSec, int hiSec) {
        if (line == null) return false;
        String[] p = line.split(" ");
        if (p.length != 3 || !p[0].equals("STATUS") || !p[1].equals(state)) return false;
        try { int sec = Integer.parseInt(p[2]); return sec >= loSec && sec <= hiSec; }
        catch (NumberFormatException e) { return false; }
    }

    /* ======================================================================
       MockStation - faithful re-implementation of TimerService.c's protocol.
       ====================================================================== */
    static final class MockStation {
        final String token, hostname, bindAddr;
        final int discPort, ctrlPort;
        volatile boolean running = true;
        DatagramSocket udp;
        ServerSocket tcp;

        // session state
        final Object lock = new Object();
        int state = 0;            // 0 STOPPED, 1 RUNNING, 2 PAUSED
        long endTimeMs = 0;       // valid when RUNNING
        int pausedRemainingSec = 0;

        MockStation(String token, String hostname, int discPort, int ctrlPort) {
            this(token, hostname, "0.0.0.0", discPort, ctrlPort);
        }
        MockStation(String token, String hostname, String bindAddr, int discPort, int ctrlPort) {
            this.token = token; this.hostname = hostname; this.bindAddr = bindAddr;
            this.discPort = discPort; this.ctrlPort = ctrlPort;
        }

        void start() throws IOException {
            InetAddress addr = InetAddress.getByName(bindAddr);
            udp = new DatagramSocket(discPort, addr);
            tcp = new ServerSocket();
            tcp.setReuseAddress(true);
            tcp.bind(new InetSocketAddress(addr, ctrlPort));
            new Thread(this::udpLoop, "mock-udp").start();
            new Thread(this::tcpLoop, "mock-tcp").start();
        }

        void stop() {
            running = false;
            try { udp.close(); } catch (Exception ignored) {}
            try { tcp.close(); } catch (Exception ignored) {}
        }

        void udpLoop() {
            byte[] buf = new byte[512];
            try {
                while (running) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    udp.receive(p);
                    String msg = new String(p.getData(), 0, p.getLength(), "US-ASCII");
                    if (msg.startsWith(CafeTimerClient.REQ_MAGIC)) {
                        String reply = CafeTimerClient.REPLY_MAGIC + "|" + hostname + "|" + ctrlPort;
                        byte[] rb = reply.getBytes("US-ASCII");
                        udp.send(new DatagramPacket(rb, rb.length, p.getAddress(), p.getPort()));
                    }
                }
            } catch (IOException e) { /* closed on stop() */ }
        }

        void tcpLoop() {
            try {
                while (running) {
                    final Socket c = tcp.accept();
                    new Thread(() -> handle(c), "mock-client").start();
                }
            } catch (IOException e) { /* closed on stop() */ }
        }

        void handle(Socket c) {
            boolean authed = (token == null || token.isEmpty());
            try {
                InputStream in = c.getInputStream();
                OutputStream out = c.getOutputStream();
                String line;
                while ((line = CafeTimerClient.readLine(in)) != null) {
                    boolean[] box = new boolean[] { authed };
                    R res = process(line, box);
                    out.write((res.first + "\n").getBytes("US-ASCII"));
                    out.flush();
                    if (res.authedNow) authed = true;
                }
            } catch (IOException ignored) {
            } finally {
                try { c.close(); } catch (IOException ignored) {}
            }
        }

        // tiny carrier so process() can both return a reply and flag auth
        static final class R { String first; boolean authedNow; R(String f){first=f;} }

        R process(String line, boolean[] authedBox) {
            // AUTH
            if (line.startsWith("AUTH ")) {
                String tok = line.substring(5).trim();
                R r;
                if (token == null || token.isEmpty()) { r = new R("OK"); }
                else if (tok.equals(token)) { r = new R("OK"); r.authedNow = true; }
                else { r = new R("ERR bad token"); }
                return r;
            }
            if (eqi(line, "GET_STATUS")) return new R(status());

            boolean authed = authedBox[0] || (token == null || token.isEmpty());
            if (!authed) return new R("ERR auth required");

            int min;
            if ((min = intArg(line, "START_SESSION")) != NOARG) {
                if (min < 1 || min > 100000) return new R("ERR minutes out of range (1..100000)");
                synchronized (lock) { state = 1; endTimeMs = System.currentTimeMillis() + (long) min * 60000L; pausedRemainingSec = 0; }
                return new R("OK");
            }
            if ((min = intArg(line, "EXTEND")) != NOARG) {
                if (min < 1 || min > 100000) return new R("ERR minutes out of range (1..100000)");
                synchronized (lock) {
                    if (state == 1) endTimeMs += (long) min * 60000L;
                    else if (state == 2) pausedRemainingSec += min * 60;
                    else { state = 1; endTimeMs = System.currentTimeMillis() + (long) min * 60000L; }
                }
                return new R("OK");
            }
            if (eqi(line, "PAUSE")) {
                synchronized (lock) {
                    if (state != 1) return new R("ERR not running");
                    long rem = (endTimeMs - System.currentTimeMillis()) / 1000L;
                    pausedRemainingSec = rem > 0 ? (int) rem : 0;
                    state = 2;
                }
                return new R("OK");
            }
            if (eqi(line, "RESUME")) {
                synchronized (lock) {
                    if (state != 2) return new R("ERR not paused");
                    endTimeMs = System.currentTimeMillis() + (long) pausedRemainingSec * 1000L;
                    state = 1;
                }
                return new R("OK");
            }
            if (eqi(line, "STOP")) {
                synchronized (lock) { state = 0; endTimeMs = 0; pausedRemainingSec = 0; }
                return new R("OK");
            }
            return new R("ERR unknown command");
        }

        String status() {
            synchronized (lock) {
                if (state == 1) {
                    long rem = (endTimeMs - System.currentTimeMillis()) / 1000L;
                    if (rem <= 0) { state = 0; endTimeMs = 0; return "STATUS STOPPED 0"; }
                    return "STATUS RUNNING " + rem;
                } else if (state == 2) {
                    return "STATUS PAUSED " + pausedRemainingSec;
                }
                return "STATUS STOPPED 0";
            }
        }

        static final int NOARG = Integer.MIN_VALUE;
        static boolean eqi(String a, String b) { return a.equalsIgnoreCase(b); }
        static int intArg(String line, String cmd) {
            if (!line.regionMatches(true, 0, cmd + " ", 0, cmd.length() + 1)) return NOARG;
            try { return Integer.parseInt(line.substring(cmd.length() + 1).trim()); }
            catch (NumberFormatException e) { return NOARG; }
        }
    }
}
