/*
 * watcher.c  ->  watcher.exe
 *
 * Runs in the background. Polls the running process list, and the moment
 * a process matching an entry in games.cfg appears, injects hook.dll into
 * it automatically. Tracks already-injected PIDs so it won't double-inject,
 * and forgets a PID once that process exits so relaunching the same game
 * gets hooked again.
 *
 * Build (MinGW-w64):
 *   gcc watcher.c -o watcher.exe -lpsapi
 *
 * Usage:
 *   watcher.exe [path_to_games.cfg] [path_to_hook.dll]
 *   (both optional - default to games.cfg and hook.dll next to the exe)
 *
 * games.cfg format - one game exe name per line, '#' for comments, e.g.:
 *   # C&C titles
 *   generalszh.exe
 *   generals.exe
 *   cnc3.exe
 *   kanewrath.exe
 */

/*
 * games.cfg format - one entry per line, '#' for comments:
 *
 *   exe_name.exe
 *     -> detect-only: watcher will inject into it whenever it sees the
 *        process appear, however it was started (by you, Steam, EA App,
 *        a shortcut, whatever). This is the original behavior.
 *
 *   exe_name.exe|C:\full\path\to\launcher_or_shortcut.exe
 *     -> launch mode: if this exe isn't already running when watcher.exe
 *        starts, watcher launches it FOR you (via ShellExecute, so this
 *        works with a real .exe path OR a .lnk shortcut path equally).
 *        Detection/injection then works exactly as above once it's
 *        running - no separate injection code path, it just gets picked
 *        up by the normal poll loop like any other launch.
 *
 * Example:
 *   generalszh.exe|C:\Users\saliya\Desktop\Zero Hour.lnk
 *   cnc3game.dat
 */

#include <windows.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <stdio.h>
#include "inject_core.h"   /* shared VirtualAllocEx + CreateRemoteThread injector */

#define MAX_GAMES     64
#define MAX_TRACKED   256
#define POLL_MS       1000

static char g_gameNames[MAX_GAMES][MAX_PATH];
static char g_gameLaunchPaths[MAX_GAMES][MAX_PATH]; /* empty string = detect-only */
static int  g_gameCount = 0;

static DWORD g_injectedPids[MAX_TRACKED];
static int   g_injectedCount = 0;

static char g_dllPath[MAX_PATH];

static void LoadGameList(const char *cfgPath) {
    FILE *f = fopen(cfgPath, "r");
    if (!f) {
        printf("[!] Could not open %s\n", cfgPath);
        return;
    }
    char line[MAX_PATH * 2];
    while (fgets(line, sizeof(line), f) && g_gameCount < MAX_GAMES) {
        /* strip newline */
        line[strcspn(line, "\r\n")] = 0;
        /* skip blank lines and comments */
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0' || *p == '#') continue;

        char *pipe = strchr(p, '|');
        if (pipe) {
            *pipe = 0;
            strncpy(g_gameNames[g_gameCount], p, MAX_PATH - 1);
            strncpy(g_gameLaunchPaths[g_gameCount], pipe + 1, MAX_PATH - 1);
        } else {
            strncpy(g_gameNames[g_gameCount], p, MAX_PATH - 1);
            g_gameLaunchPaths[g_gameCount][0] = 0;
        }
        g_gameNames[g_gameCount][MAX_PATH - 1] = 0;
        g_gameLaunchPaths[g_gameCount][MAX_PATH - 1] = 0;
        g_gameCount++;
    }
    fclose(f);
    printf("[+] Loaded %d game(s) from %s\n", g_gameCount, cfgPath);
    for (int i = 0; i < g_gameCount; i++) {
        if (g_gameLaunchPaths[i][0]) {
            printf("      - %s  (auto-launch: %s)\n", g_gameNames[i], g_gameLaunchPaths[i]);
        } else {
            printf("      - %s  (detect-only)\n", g_gameNames[i]);
        }
    }
}

static int IsProcessRunning(const char *exeName) {
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;

    int found = 0;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, exeName) == 0) { found = 1; break; }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

/* One-time pass at startup: for every configured game that has a launch
   path and isn't already running, start it. ShellExecute handles a plain
   .exe path and a .lnk shortcut path identically, so games.cfg can point
   at either. Detection/injection then proceeds exactly as normal once
   the process shows up in the poll loop below - no separate code path. */
static void LaunchConfiguredGames(void) {
    for (int i = 0; i < g_gameCount; i++) {
        if (!g_gameLaunchPaths[i][0]) continue; /* detect-only entry */

        if (IsProcessRunning(g_gameNames[i])) {
            printf("[*] %s is already running - not launching\n", g_gameNames[i]);
            continue;
        }

        printf("[*] Launching %s ...\n", g_gameLaunchPaths[i]);
        HINSTANCE result = ShellExecuteA(NULL, "open", g_gameLaunchPaths[i], NULL, NULL, SW_SHOWNORMAL);
        if ((INT_PTR)result <= 32) {
            printf("    [!] ShellExecute failed, code %lld - check the path in games.cfg\n", (long long)(INT_PTR)result);
        }
    }
}
static int IsConfiguredGame(const char *exeName) {
    for (int i = 0; i < g_gameCount; i++) {
        if (_stricmp(exeName, g_gameNames[i]) == 0) return 1;
    }
    return 0;
}

static int IsAlreadyInjected(DWORD pid) {
    for (int i = 0; i < g_injectedCount; i++) {
        if (g_injectedPids[i] == pid) return 1;
    }
    return 0;
}

static void RememberInjected(DWORD pid) {
    if (g_injectedCount < MAX_TRACKED) {
        g_injectedPids[g_injectedCount++] = pid;
    }
}

/* Remove PIDs from the tracked list whose process has exited, so a
   relaunch of the same exe gets detected and hooked again. */
static void PruneDeadPids(void) {
    int writeIdx = 0;
    for (int i = 0; i < g_injectedCount; i++) {
        HANDLE h = OpenProcess(SYNCHRONIZE, FALSE, g_injectedPids[i]);
        int alive = 0;
        if (h) {
            alive = (WaitForSingleObject(h, 0) == WAIT_TIMEOUT);
            CloseHandle(h);
        }
        if (alive) g_injectedPids[writeIdx++] = g_injectedPids[i];
    }
    g_injectedCount = writeIdx;
}

static void ScanAndInject(void) {
    enum { SCAN_BATCH = 16 }; /* far more concurrent games than ever realistic */
    DWORD pids[SCAN_BATCH];
    char  names[SCAN_BATCH][MAX_PATH];
    int   count = 0;

    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return;

    /* Collect targets first, then release the snapshot BEFORE the 1.5s
       settle wait + injection, instead of holding it (and blocking the
       enumeration) across that slow work. */
    if (Process32First(snap, &pe)) {
        do {
            if (!IsConfiguredGame(pe.szExeFile)) continue;
            if (IsAlreadyInjected(pe.th32ProcessID)) continue;
            if (count >= SCAN_BATCH) break;
            pids[count] = pe.th32ProcessID;
            strncpy(names[count], pe.szExeFile, MAX_PATH - 1);
            names[count][MAX_PATH - 1] = 0;
            count++;
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);

    for (int i = 0; i < count; i++) {
        printf("[+] Detected %s (PID %lu) - injecting...\n", names[i], pids[i]);

        /* Let the game finish its own early init before we inject */
        Sleep(1500);

        char err[256];
        if (InjectDllIntoPid(pids[i], g_dllPath, err, sizeof(err)) == 0) {
            printf("[+] Injected into %s successfully\n", names[i]);
        } else {
            printf("[!] Injection into %s failed: %s\n", names[i], err);
        }
        RememberInjected(pids[i]); /* remember either way - don't retry-spam */
    }
}

int main(int argc, char **argv) {
    char exeDir[MAX_PATH];
    GetModuleFileNameA(NULL, exeDir, MAX_PATH);
    char *lastSlash = strrchr(exeDir, '\\');
    if (lastSlash) *(lastSlash + 1) = 0;

    char cfgPath[MAX_PATH];
    if (argc > 1) {
        strncpy(cfgPath, argv[1], MAX_PATH - 1);
    } else {
        snprintf(cfgPath, MAX_PATH, "%sgames.cfg", exeDir);
    }

    if (argc > 2) {
        strncpy(g_dllPath, argv[2], MAX_PATH - 1);
        g_dllPath[MAX_PATH - 1] = 0;
    } else {
        /* watcher is single-arch (legacy standalone tool) - default to the
           hook matching how it was built. build.bat builds watcher 32-bit
           for the 32-bit C&C titles, so hook32.dll is the right default;
           pass an explicit path as arg 2 for anything else. */
        snprintf(g_dllPath, MAX_PATH, "%shook32.dll", exeDir);
    }

    printf("[*] Watcher started.\n");
    printf("[*] Config: %s\n", cfgPath);
    printf("[*] DLL:    %s\n", g_dllPath);

    LoadGameList(cfgPath);
    if (g_gameCount == 0) {
        printf("[!] No games configured - nothing to watch for. Exiting.\n");
        return 1;
    }

    printf("[*] Watching for configured games (Ctrl+C to stop)...\n");

    LaunchConfiguredGames();

    while (1) {
        PruneDeadPids();
        ScanAndInject();
        Sleep(POLL_MS);
    }

    return 0;
}
