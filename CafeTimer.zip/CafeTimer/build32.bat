@echo off
REM Build the 32-bit pieces. Run from an MSYS2 "MINGW32" shell (gcc = i686).
REM Produces: hook32.dll, injhelper32.exe, injector.exe, watcher.exe
REM Run from the project folder (so minhook\ resolves).

echo [32-bit] hook32.dll
gcc -shared -o hook32.dll hook.c minhook\src\*.c minhook\src\hde\*.c -Iminhook\include -ld3d9 -lgdi32 -lws2_32 -static-libgcc

echo [32-bit] injhelper32.exe
gcc injhelper.c -o injhelper32.exe -static-libgcc

echo [32-bit] injector.exe + watcher.exe (with admin manifest)
windres admin.rc -O coff -o admin_res.o
gcc injector.c admin_res.o -o injector.exe -static-libgcc
gcc watcher.c  admin_res.o -o watcher.exe  -lshell32 -static-libgcc
del admin_res.o

echo [32-bit] done.
