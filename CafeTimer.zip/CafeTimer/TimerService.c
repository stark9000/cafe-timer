/*
 * TimerService.c  ->  TimerService.exe
 *
 * Step 1: Windows Service scaffolding (install/uninstall/start/stop/
 * crash-recovery) - done and tested.
 *
 * Step 2 (this version): UDP discovery. A background thread listens on
 * a fixed UDP port for a broadcast discovery request from the Java
 * Swing server and replies (unicast) with this station's hostname and
 * the TCP control port it will listen on (control server itself isn't
 * built yet - next step - but the port number is already fixed so the
 * discovery reply can announce it now).
 *
 * Build (MinGW-w64):
 *   gcc TimerService.c -o TimerService.exe -ladvapi32 -lws2_32 -lwtsapi32 -luserenv -static-libgcc
 *   (wtsapi32 for WTSQueryUserToken, userenv for Create/DestroyEnvironmentBlock -
 *    the old line omitted both and would not link once Agent launching
 *    was added. build.bat has the correct invocation.)
 *
 * Usage (must be run as Administrator):
 *   TimerService.exe install     - registers the service with Windows,
 *                                  sets it to auto-start on boot,
 *                                  configures auto-restart on crash, and
 *                                  opens firewall rules for the
 *                                  discovery UDP port and control TCP port
 *   TimerService.exe uninstall   - stops (if running), removes the
 *                                  service and its firewall rules
 *   TimerService.exe             - (no args) this is how Windows itself
 *                                  launches it once installed
 *
 * After installing: `sc start CafeTimer` to start it immediately
 * without waiting for a reboot. `sc query CafeTimer` to check
 * status. `sc qc CafeTimer` to see its configuration.
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>        /* _commit / _fileno - force session file to disk */
#include <wtsapi32.h>
#include <userenv.h>

#define SERVICE_NAME "CafeTimer"
#define SERVICE_DISPLAY_NAME "Cafe Timer"

#define DISCOVERY_PORT 47100
#define CONTROL_PORT   47200   /* not implemented yet - announced now so the
                                   Java server already knows where to connect
                                   once the TCP control server exists */
/* Wire-protocol discovery tokens. These are a CONTRACT with the Java
   server and are deliberately NOT rebranded - changing them is a breaking
   protocol change that would also require updating the Java side. The
   product rename (Cafe Timer) is cosmetic/service-level only. */
#define DISCOVERY_REQUEST_MAGIC "TIMERCAFE_DISCOVER_V1"
#define DISCOVERY_REPLY_MAGIC   "TIMERCAFE_HERE_V1"

/* Sanity bounds on session length. Rejects negatives (which used to wrap
   to a near-infinite end time via the unsigned cast) and absurd values.
   100000 minutes is ~69 days - comfortably past any real cafe session. */
#define MIN_SESSION_MINUTES 1
#define MAX_SESSION_MINUTES 100000

/* Cap simultaneous control connections so a misbehaving or hostile LAN
   peer can't spawn unbounded handler threads. The overlays and the Java
   server together use only a handful at a time. */
#define CONTROL_MAX_CLIENTS 32
static volatile LONG g_clientThreadCount = 0;

/* Optional shared-secret auth for state-changing control commands.
   Loaded from control_token.cfg next to the exe. If that file is absent
   or empty the server runs OPEN (backward compatible) and logs a loud
   warning; if a token is present, START_SESSION/EXTEND/PAUSE/RESUME/STOP
   all require a prior AUTH <token>. GET_STATUS is always open (the
   overlays need it, and it leaks nothing worth protecting). */
static int  g_requireAuth = 0;
static char g_controlToken[128] = "";
static char g_controlTokenPath[MAX_PATH];

static HANDLE g_udpThread = NULL;


static SERVICE_STATUS g_serviceStatus;
static SERVICE_STATUS_HANDLE g_statusHandle = NULL;
static HANDLE g_serviceStopEvent = NULL;
static char g_logFilePath[MAX_PATH];
static char g_sessionFilePath[MAX_PATH];
static HANDLE g_tcpThread = NULL;
static HANDLE g_agentSupervisorThread = NULL;
static HANDLE g_agentProcessHandle = NULL;
static DWORD g_agentSessionId = 0xFFFFFFFF; /* session the Agent was last launched into */
static char g_agentExePath[MAX_PATH];
/* Guards g_agentProcessHandle / g_agentSessionId, which are touched by
   both the supervisor thread and the shutdown path in ServiceMain. */
static CRITICAL_SECTION g_agentCs;

/* ---------------------------- logging ---------------------------- */
/* Simple synchronous logging is fine here - this is NOT a per-frame
   render hook, there's no tight timing budget like there was in
   hook.dll. Kept deliberately simple for this first step. */

static void InitLogPath(void) {
    char selfPath[MAX_PATH];
    GetModuleFileNameA(NULL, selfPath, MAX_PATH);
    char *lastSlash = strrchr(selfPath, '\\');
    if (lastSlash) *(lastSlash + 1) = 0;
    snprintf(g_logFilePath, MAX_PATH, "%sservice_log.txt", selfPath);
    snprintf(g_sessionFilePath, MAX_PATH, "%ssession_state.txt", selfPath);
    snprintf(g_agentExePath, MAX_PATH, "%sAgent.exe", selfPath);
    snprintf(g_controlTokenPath, MAX_PATH, "%scontrol_token.cfg", selfPath);
}

static void LogMsg(const char *msg) {
    FILE *f = fopen(g_logFilePath, "a");
    if (f) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        fprintf(f, "[%04d-%02d-%02d %02d:%02d:%02d] %s\n",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, msg);
        fclose(f);
    }
}

/* ---------------------------- session state ---------------------------- */
/*
 * The whole point of this module: if the service crashes, gets force-
 * killed, or the entire PC loses power, the customer's remaining time
 * must come back EXACTLY right afterward - not reset, not frozen, not
 * confused by however long the outage lasted.
 *
 * The trick is to never store "seconds remaining" as a number that
 * ticks down in memory - that number is exactly what a crash destroys.
 * Instead we store ONE thing to disk: the absolute moment the session
 * ends (as a FILETIME - 100ns units since 1601 UTC, immune to timezone/
 * DST changes unlike local time). Anyone asking "how much time is left"
 * gets endTime-minus-now, computed fresh every time. That single design
 * choice makes recovery trivial: reload that one value from disk, do
 * the subtraction, done - correct to the second, no separate tracking
 * of "how long were we down" ever needed.
 *
 * PAUSE is the one exception - there's no ticking clock to represent
 * while paused, so we freeze a plain remaining-seconds count instead,
 * and convert it back to a fresh absolute end time on RESUME.
 */

#define SESSION_STOPPED 0
#define SESSION_RUNNING 1
#define SESSION_PAUSED  2

static CRITICAL_SECTION g_sessionCs;
static int g_sessionState = SESSION_STOPPED;
static ULONGLONG g_endTimeFT = 0;       /* FILETIME 100ns units - valid when RUNNING */
static LONG g_pausedRemainingSec = 0;   /* valid when PAUSED */

static ULONGLONG NowFileTime(void) {
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft); /* UTC - immune to local timezone/DST changes */
    ULARGE_INTEGER uli;
    uli.LowPart = ft.dwLowDateTime;
    uli.HighPart = ft.dwHighDateTime;
    return uli.QuadPart;
}

/* Caller must hold g_sessionCs.
 *
 * Crash/power-loss safe. The entire recovery design hinges on this file
 * surviving a hard outage intact, so we never truncate the real file in
 * place (the old fopen("w") did exactly that - a power cut mid-write left
 * a half-written file that reads back as a short/garbage END_FILETIME and
 * silently drops the customer's remaining time). Instead: write a temp
 * file, force it through the CRT buffer AND the OS write cache onto the
 * physical disk, then atomically swap it over the real file. At every
 * instant the on-disk file is EITHER the complete old state or the
 * complete new state - never a torn one. */
static void SaveSessionStateLocked(void) {
    char tmpPath[MAX_PATH];
    snprintf(tmpPath, sizeof(tmpPath), "%s.tmp", g_sessionFilePath);

    FILE *f = fopen(tmpPath, "w");
    if (!f) {
        LogMsg("SaveSessionState: could not open temp file - state NOT persisted this time");
        return;
    }
    fprintf(f, "STATE=%d\nEND_FILETIME=%llu\nPAUSED_REMAINING=%ld\n",
            g_sessionState, (unsigned long long)g_endTimeFT, (long)g_pausedRemainingSec);

    /* fflush drains the CRT buffer into the OS; _commit forces the OS to
       flush to the physical disk. Without both, an "atomic rename" can
       still expose an empty file after a crash because the data behind it
       never actually reached the platter. */
    fflush(f);
    _commit(_fileno(f));
    fclose(f);

    if (!MoveFileExA(tmpPath, g_sessionFilePath,
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        LogMsg("SaveSessionState: atomic replace failed - previous state file left intact");
    }
}

static void LoadSessionState(void) {
    InitializeCriticalSection(&g_sessionCs);
    EnterCriticalSection(&g_sessionCs);

    FILE *f = fopen(g_sessionFilePath, "r");
    if (f) {
        int state = SESSION_STOPPED;
        unsigned long long endFt = 0;
        long pausedRem = 0;
        char lineBuf[128];
        while (fgets(lineBuf, sizeof(lineBuf), f)) {
            sscanf(lineBuf, "STATE=%d", &state);
            sscanf(lineBuf, "END_FILETIME=%llu", &endFt);
            sscanf(lineBuf, "PAUSED_REMAINING=%ld", &pausedRem);
        }
        fclose(f);

        g_sessionState = state;
        g_endTimeFT = endFt;
        g_pausedRemainingSec = pausedRem;

        /* If we were RUNNING and the end time already passed while we
           were down (crash, restart, or the whole PC being off), resolve
           to STOPPED now rather than silently reporting a stale/negative
           remaining time to the next thing that asks. */
        if (g_sessionState == SESSION_RUNNING && g_endTimeFT <= NowFileTime()) {
            g_sessionState = SESSION_STOPPED;
            g_endTimeFT = 0;
            SaveSessionStateLocked();
        }

        char msg[128];
        snprintf(msg, sizeof(msg), "Session state loaded from disk: state=%d", g_sessionState);
        LogMsg(msg);
    } else {
        g_sessionState = SESSION_STOPPED;
        LogMsg("No previous session state file found - starting STOPPED");
    }

    LeaveCriticalSection(&g_sessionCs);
}

static void StartSession(int minutes) {
    EnterCriticalSection(&g_sessionCs);
    g_sessionState = SESSION_RUNNING;
    g_endTimeFT = NowFileTime() + (ULONGLONG)minutes * 60ULL * 10000000ULL;
    g_pausedRemainingSec = 0;
    SaveSessionStateLocked();
    LeaveCriticalSection(&g_sessionCs);

    char msg[64];
    snprintf(msg, sizeof(msg), "StartSession(%d minutes)", minutes);
    LogMsg(msg);
}

static void ExtendSession(int minutes) {
    EnterCriticalSection(&g_sessionCs);
    if (g_sessionState == SESSION_RUNNING) {
        g_endTimeFT += (ULONGLONG)minutes * 60ULL * 10000000ULL;
    } else if (g_sessionState == SESSION_PAUSED) {
        g_pausedRemainingSec += minutes * 60;
        if (g_pausedRemainingSec < 0) g_pausedRemainingSec = 0;
    } else {
        /* STOPPED - treat EXTEND as starting a fresh session, for
           convenience (owner adding time to a station nobody has
           started a session on yet). */
        g_sessionState = SESSION_RUNNING;
        g_endTimeFT = NowFileTime() + (ULONGLONG)minutes * 60ULL * 10000000ULL;
    }
    SaveSessionStateLocked();
    LeaveCriticalSection(&g_sessionCs);

    char msg[64];
    snprintf(msg, sizeof(msg), "ExtendSession(%d minutes)", minutes);
    LogMsg(msg);
}

static int PauseSession(void) {
    int ok = 0;
    EnterCriticalSection(&g_sessionCs);
    if (g_sessionState == SESSION_RUNNING) {
        ULONGLONG now = NowFileTime();
        LONGLONG remain100ns = (LONGLONG)(g_endTimeFT - now);
        g_pausedRemainingSec = (remain100ns > 0) ? (LONG)(remain100ns / 10000000LL) : 0;
        g_sessionState = SESSION_PAUSED;
        SaveSessionStateLocked();
        ok = 1;
    }
    LeaveCriticalSection(&g_sessionCs);
    LogMsg(ok ? "PauseSession() - paused" : "PauseSession() - ignored, not running");
    return ok;
}

static int ResumeSession(void) {
    int ok = 0;
    EnterCriticalSection(&g_sessionCs);
    if (g_sessionState == SESSION_PAUSED) {
        g_endTimeFT = NowFileTime() + (ULONGLONG)g_pausedRemainingSec * 10000000ULL;
        g_sessionState = SESSION_RUNNING;
        SaveSessionStateLocked();
        ok = 1;
    }
    LeaveCriticalSection(&g_sessionCs);
    LogMsg(ok ? "ResumeSession() - resumed" : "ResumeSession() - ignored, not paused");
    return ok;
}

static void StopSession(void) {
    EnterCriticalSection(&g_sessionCs);
    g_sessionState = SESSION_STOPPED;
    g_endTimeFT = 0;
    g_pausedRemainingSec = 0;
    SaveSessionStateLocked();
    LeaveCriticalSection(&g_sessionCs);
    LogMsg("StopSession()");
}

/* Computes the live remaining time. Also lazily notices expiry right
   here (not just at service startup) - the moment ANYTHING asks for
   status after the end time has passed, we flip to STOPPED and persist
   that, rather than only checking at load time. */
static void GetStatus(const char **stateNameOut, long *remainingOut) {
    EnterCriticalSection(&g_sessionCs);

    if (g_sessionState == SESSION_RUNNING) {
        ULONGLONG now = NowFileTime();
        if (g_endTimeFT <= now) {
            g_sessionState = SESSION_STOPPED;
            g_endTimeFT = 0;
            SaveSessionStateLocked();
            *stateNameOut = "STOPPED";
            *remainingOut = 0;
        } else {
            *stateNameOut = "RUNNING";
            *remainingOut = (long)((g_endTimeFT - now) / 10000000ULL);
        }
    } else if (g_sessionState == SESSION_PAUSED) {
        *stateNameOut = "PAUSED";
        *remainingOut = g_pausedRemainingSec;
    } else {
        *stateNameOut = "STOPPED";
        *remainingOut = 0;
    }

    LeaveCriticalSection(&g_sessionCs);
}

/* ---------------------------- Agent launching + supervision ---------------------------- */
/*
 * The Service runs as SYSTEM in Session 0, which is isolated from the
 * customer's interactive desktop session (Vista+ Session 0 isolation) -
 * it cannot inject into games directly. This is why Agent.exe exists:
 * a normal, non-elevated process launched INTO the customer's own
 * session, which does the actual DLL injection.
 *
 * Getting a SYSTEM process to launch something into another session at
 * the customer's own privilege level takes a specific sequence:
 *   1. WTSGetActiveConsoleSessionId() - which session is the one with
 *      someone actually logged in and looking at a screen right now
 *   2. WTSQueryUserToken() - get that user's own access token (requires
 *      the SE_TCB_NAME privilege enabled in OUR token first - LocalSystem
 *      is GRANTED this privilege but it isn't enabled by default, so we
 *      explicitly enable it once at startup)
 *   3. DuplicateTokenEx() - turn that into a primary token usable to
 *      spawn a new process (the token WTSQueryUserToken gives you is an
 *      impersonation token, not directly usable as-is for CreateProcessAsUser)
 *   4. CreateEnvironmentBlock() - build the correct environment (PATH,
 *      USERPROFILE, etc) for that user, not the Service's own SYSTEM
 *      environment
 *   5. CreateProcessAsUser() with lpDesktop = "winsta0\\default" so it
 *      actually appears on the interactive desktop, not some invisible
 *      non-interactive one
 *
 * Supervision here is deliberately simple (polling), not a full
 * WTS session-change event subscription - every few seconds we check:
 * is the Agent process still alive, and is the active console session
 * still the one we launched into. Either condition failing triggers a
 * relaunch. This covers "customer killed the Agent" (same self-healing
 * principle as the Service protecting itself) and "a different user
 * logged in" reasonably well without the extra complexity of proper
 * SERVICE_CONTROL_SESSIONCHANGE handling - a reasonable simplification
 * for now, worth revisiting if session-switch timing ever matters more.
 */

static BOOL EnablePrivilege(LPCSTR privName) {
    HANDLE hToken;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
        return FALSE;
    }

    TOKEN_PRIVILEGES tp;
    LUID luid;
    if (!LookupPrivilegeValueA(NULL, privName, &luid)) {
        CloseHandle(hToken);
        return FALSE;
    }

    tp.PrivilegeCount = 1;
    tp.Privileges[0].Luid = luid;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    BOOL adjustOk = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
    DWORD err = GetLastError();
    CloseHandle(hToken);
    return adjustOk && err == ERROR_SUCCESS;
}

/* Launches Agent.exe into whatever session is currently active. Returns
   TRUE and fills g_agentProcessHandle/g_agentSessionId on success. */
static BOOL LaunchAgentIntoUserSession(void) {
    DWORD sessionId = WTSGetActiveConsoleSessionId();
    if (sessionId == 0xFFFFFFFF) {
        LogMsg("LaunchAgent: no active console session (login screen / locked with "
               "no user?) - will retry");
        return FALSE;
    }

    HANDLE hUserToken;
    if (!WTSQueryUserToken(sessionId, &hUserToken)) {
        char msg[128];
        snprintf(msg, sizeof(msg), "LaunchAgent: WTSQueryUserToken failed, error %lu "
                                    "(is SE_TCB_NAME enabled?)", GetLastError());
        LogMsg(msg);
        return FALSE;
    }

    HANDLE hDupToken;
    BOOL dupOk = DuplicateTokenEx(hUserToken, MAXIMUM_ALLOWED, NULL,
                                   SecurityImpersonation, TokenPrimary, &hDupToken);
    CloseHandle(hUserToken);
    if (!dupOk) {
        char msg[128];
        snprintf(msg, sizeof(msg), "LaunchAgent: DuplicateTokenEx failed, error %lu", GetLastError());
        LogMsg(msg);
        return FALSE;
    }

    LPVOID envBlock = NULL;
    if (!CreateEnvironmentBlock(&envBlock, hDupToken, FALSE)) {
        LogMsg("LaunchAgent: CreateEnvironmentBlock failed - continuing with no custom environment");
        envBlock = NULL;
    }

    STARTUPINFOA si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.lpDesktop = (LPSTR)"winsta0\\default"; /* the actual interactive desktop */

    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));

    char cmdLine[MAX_PATH + 16];
    snprintf(cmdLine, sizeof(cmdLine), "\"%s\"", g_agentExePath);

    /* CREATE_NO_WINDOW: Agent.exe is a console-subsystem app, but we
       don't want a visible console flashing up in the customer's
       session - it already logs to agent_log.txt for diagnostics. */
    BOOL created = CreateProcessAsUserA(
        hDupToken, NULL, cmdLine, NULL, NULL, FALSE,
        CREATE_UNICODE_ENVIRONMENT | CREATE_NO_WINDOW,
        envBlock, NULL, &si, &pi);

    DWORD createErr = GetLastError();

    if (envBlock) DestroyEnvironmentBlock(envBlock);
    CloseHandle(hDupToken);

    if (!created) {
        char msg[160];
        snprintf(msg, sizeof(msg), "LaunchAgent: CreateProcessAsUser failed, error %lu "
                                    "(path: %s)", createErr, g_agentExePath);
        LogMsg(msg);
        return FALSE;
    }

    CloseHandle(pi.hThread);

    EnterCriticalSection(&g_agentCs);
    if (g_agentProcessHandle) CloseHandle(g_agentProcessHandle);
    g_agentProcessHandle = pi.hProcess;
    g_agentSessionId = sessionId;
    LeaveCriticalSection(&g_agentCs);

    char msg[128];
    snprintf(msg, sizeof(msg), "LaunchAgent: launched successfully (PID %lu, session %lu)",
             pi.dwProcessId, sessionId);
    LogMsg(msg);
    return TRUE;
}

static DWORD WINAPI AgentSupervisorThread(LPVOID unused) {
    (void)unused;

    /* SE_TCB_NAME ("Act as part of the operating system") is what
       WTSQueryUserToken needs - LocalSystem is granted this privilege
       but it isn't enabled in the token by default, so enable it once here. */
    if (!EnablePrivilege("SeTcbPrivilege")) {
        LogMsg("AgentSupervisor: could not enable SeTcbPrivilege - Agent launching will fail. "
               "This should not happen when running as LocalSystem.");
    }

    while (WaitForSingleObject(g_serviceStopEvent, 0) != WAIT_OBJECT_0) {
        BOOL needsLaunch = FALSE;

        /* Snapshot the shared fields under the lock, then reason about the
           snapshot. Any close-and-forget is done back under the lock, and
           only if the handle hasn't changed underneath us - so we never
           double-close one the shutdown path already reclaimed. */
        EnterCriticalSection(&g_agentCs);
        HANDLE curHandle = g_agentProcessHandle;
        DWORD  curSession = g_agentSessionId;
        LeaveCriticalSection(&g_agentCs);

        if (!curHandle) {
            needsLaunch = TRUE;
        } else if (WaitForSingleObject(curHandle, 0) == WAIT_OBJECT_0) {
            LogMsg("AgentSupervisor: Agent process has exited - relaunching");
            EnterCriticalSection(&g_agentCs);
            if (g_agentProcessHandle == curHandle) {
                CloseHandle(g_agentProcessHandle);
                g_agentProcessHandle = NULL;
            }
            LeaveCriticalSection(&g_agentCs);
            needsLaunch = TRUE;
        } else {
            DWORD currentSession = WTSGetActiveConsoleSessionId();
            if (currentSession != 0xFFFFFFFF && currentSession != curSession) {
                LogMsg("AgentSupervisor: active session changed - relaunching Agent into new session");
                /* The old Agent process is in a session that's no longer
                   active/console-attached - it isn't reachable to
                   terminate cleanly the same way, and Windows will clean
                   it up when that session eventually ends. Just forget
                   our handle to it and launch fresh into the new session. */
                EnterCriticalSection(&g_agentCs);
                if (g_agentProcessHandle == curHandle) {
                    CloseHandle(g_agentProcessHandle);
                    g_agentProcessHandle = NULL;
                }
                LeaveCriticalSection(&g_agentCs);
                needsLaunch = TRUE;
            }
        }

        if (needsLaunch) {
            LaunchAgentIntoUserSession();
        }

        /* Check every 5 seconds - responsive enough for a customer
           killing the Agent, without hammering WTS/session APIs. */
        if (WaitForSingleObject(g_serviceStopEvent, 5000) == WAIT_OBJECT_0) break;
    }

    LogMsg("AgentSupervisor thread exiting (stop requested)");
    return 0;
}

/* ---------------------------- install / uninstall ---------------------------- */

static int InstallService(void) {
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);

    SC_HANDLE scm = OpenSCManagerA(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
    if (!scm) {
        printf("[!] OpenSCManager failed (%lu) - run as Administrator\n", GetLastError());
        return 1;
    }

    /* lpServiceStartName = NULL -> runs as LocalSystem, which is what
       we need later for CreateProcessAsUser (launching the Agent into
       the customer's desktop session), LockWorkStation/ExitWindowsEx,
       and TerminateProcess on arbitrary processes. */
    SC_HANDLE svc = CreateServiceA(
        scm, SERVICE_NAME, SERVICE_DISPLAY_NAME,
        SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
        SERVICE_AUTO_START, SERVICE_ERROR_NORMAL,
        exePath, NULL, NULL, NULL, NULL, NULL);

    if (!svc) {
        DWORD err = GetLastError();
        if (err == ERROR_SERVICE_EXISTS) {
            printf("[!] Service already installed. Run 'uninstall' first if you want to reinstall.\n");
        } else {
            printf("[!] CreateService failed, error %lu\n", err);
        }
        CloseServiceHandle(scm);
        return 1;
    }

    /* Configure auto-restart on crash: restart after 5s on the first
       failure, 10s on the second, 30s on any subsequent one within the
       reset period. This is what makes "someone kills the service"
       self-healing without any code of our own - Windows does it. */
    SERVICE_FAILURE_ACTIONSA failureActions;
    SC_ACTION actions[3];
    actions[0].Type = SC_ACTION_RESTART; actions[0].Delay = 5000;
    actions[1].Type = SC_ACTION_RESTART; actions[1].Delay = 10000;
    actions[2].Type = SC_ACTION_RESTART; actions[2].Delay = 30000;

    ZeroMemory(&failureActions, sizeof(failureActions));
    failureActions.dwResetPeriod = 86400; /* reset failure count after 1 day of stability */
    failureActions.lpRebootMsg = NULL;
    failureActions.lpCommand = NULL;
    failureActions.cActions = 3;
    failureActions.lpsaActions = actions;

    if (!ChangeServiceConfig2A(svc, SERVICE_CONFIG_FAILURE_ACTIONS, &failureActions)) {
        printf("[!] Warning: ChangeServiceConfig2 (failure actions) failed, error %lu - "
               "service installed but won't auto-restart on crash\n", GetLastError());
    }

    /* On modern Windows, failure actions only fire for actual crashes by
       default - SERVICE_CONFIG_FAILURE_ACTIONS_FLAG with fFailureActionsOnNonCrashFailures=TRUE
       makes them also fire if the service just exits/stops unexpectedly
       without crashing, which is the more likely "someone force-killed it" case. */
    SERVICE_FAILURE_ACTIONS_FLAG flag;
    flag.fFailureActionsOnNonCrashFailures = TRUE;
    if (!ChangeServiceConfig2A(svc, SERVICE_CONFIG_FAILURE_ACTIONS_FLAG, &flag)) {
        printf("[!] Warning: ChangeServiceConfig2 (failure flag) failed, error %lu\n", GetLastError());
    }

    /* Open firewall ports for UDP discovery and the (future) TCP control
       server, so a fresh Windows Firewall install doesn't silently
       swallow the discovery replies - a very easy thing to lose an hour
       to otherwise, since a blocked port just looks like "nothing
       responds", not an explicit error anywhere. */
    system("netsh advfirewall firewall add rule name=\"Cafe Timer Discovery (UDP)\" "
           "dir=in action=allow protocol=UDP localport=47100 >nul 2>&1");
    system("netsh advfirewall firewall add rule name=\"Cafe Timer Control (TCP)\" "
           "dir=in action=allow protocol=TCP localport=47200 >nul 2>&1");

    printf("[+] Service installed successfully.\n");
    printf("[+] Start it now with:  sc start %s\n", SERVICE_NAME);
    printf("[+] Or it will start automatically on next boot.\n");

    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return 0;
}

static int UninstallService(void) {
    SC_HANDLE scm = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (!scm) {
        printf("[!] OpenSCManager failed (%lu) - run as Administrator\n", GetLastError());
        return 1;
    }

    SC_HANDLE svc = OpenServiceA(scm, SERVICE_NAME, SERVICE_STOP | DELETE | SERVICE_QUERY_STATUS);
    if (!svc) {
        printf("[!] Service not found (error %lu) - nothing to uninstall\n", GetLastError());
        CloseServiceHandle(scm);
        return 1;
    }

    SERVICE_STATUS status;
    if (ControlService(svc, SERVICE_CONTROL_STOP, &status)) {
        printf("[*] Stop requested, waiting for it to fully stop...\n");
        Sleep(1500);
    }

    if (DeleteService(svc)) {
        printf("[+] Service uninstalled successfully.\n");
        system("netsh advfirewall firewall delete rule name=\"Cafe Timer Discovery (UDP)\" >nul 2>&1");
        system("netsh advfirewall firewall delete rule name=\"Cafe Timer Control (TCP)\" >nul 2>&1");
    } else {
        printf("[!] DeleteService failed, error %lu\n", GetLastError());
    }

    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return 0;
}

/* ---------------------------- service runtime ---------------------------- */

static void ReportServiceStatus(DWORD currentState, DWORD win32ExitCode, DWORD waitHint) {
    static DWORD checkPoint = 1;

    g_serviceStatus.dwCurrentState = currentState;
    g_serviceStatus.dwWin32ExitCode = win32ExitCode;
    g_serviceStatus.dwWaitHint = waitHint;

    g_serviceStatus.dwControlsAccepted =
        (currentState == SERVICE_START_PENDING) ? 0 : (SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN);

    if (currentState == SERVICE_RUNNING || currentState == SERVICE_STOPPED) {
        g_serviceStatus.dwCheckPoint = 0;
    } else {
        g_serviceStatus.dwCheckPoint = checkPoint++;
    }

    SetServiceStatus(g_statusHandle, &g_serviceStatus);
}

static DWORD WINAPI ServiceCtrlHandlerEx(DWORD ctrl, DWORD eventType, LPVOID eventData, LPVOID context) {
    (void)eventType; (void)eventData; (void)context;
    switch (ctrl) {
        case SERVICE_CONTROL_STOP:
        case SERVICE_CONTROL_SHUTDOWN:
            LogMsg("Stop/shutdown control received");
            /* Wait hint covers the worst case of the sequential thread
               joins in ServiceMain (UDP 3s + TCP 3s + supervisor 7s);
               in practice all three wake on the event and stop in ~1s. */
            ReportServiceStatus(SERVICE_STOP_PENDING, NO_ERROR, 15000);
            SetEvent(g_serviceStopEvent);
            return NO_ERROR;
        default:
            return NO_ERROR;
    }
}

/* This is where all the real work will live once we add networking:
   UDP discovery responder, TCP control server, session state, Agent
   supervision. For this first step, it's just a heartbeat so we can
   confirm the service installs, starts, survives, and stops cleanly. */
static void RunServiceMainLoop(void) {
    int heartbeat = 0;
    while (WaitForSingleObject(g_serviceStopEvent, 10000) == WAIT_TIMEOUT) {
        char msg[64];
        snprintf(msg, sizeof(msg), "heartbeat #%d - service is alive", ++heartbeat);
        LogMsg(msg);
    }
}

/* ---------------------------- UDP discovery ---------------------------- */

/* Listens for a broadcast discovery request and replies (unicast) with
   this station's hostname and control port. Uses a receive timeout
   rather than blocking forever, so it can periodically check the stop
   event and exit promptly when the service is asked to stop - Windows
   expects a service to actually stop within its reported wait hint. */
static DWORD WINAPI UdpDiscoveryThread(LPVOID unused) {
    (void)unused;

    SOCKET sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET) {
        LogMsg("UDP discovery: socket() failed");
        return 0;
    }

    BOOL reuse = TRUE;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof(reuse));

    struct sockaddr_in bindAddr;
    ZeroMemory(&bindAddr, sizeof(bindAddr));
    bindAddr.sin_family = AF_INET;
    bindAddr.sin_addr.s_addr = INADDR_ANY;
    bindAddr.sin_port = htons(DISCOVERY_PORT);

    if (bind(sock, (struct sockaddr *)&bindAddr, sizeof(bindAddr)) == SOCKET_ERROR) {
        char msg[128];
        snprintf(msg, sizeof(msg), "UDP discovery: bind() failed, WSAGetLastError=%d "
                                    "(port %d already in use?)", WSAGetLastError(), DISCOVERY_PORT);
        LogMsg(msg);
        closesocket(sock);
        return 0;
    }

    /* Poll instead of blocking forever, so we notice the stop event. */
    DWORD recvTimeoutMs = 1000;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char *)&recvTimeoutMs, sizeof(recvTimeoutMs));

    char hostname[256] = "unknown-host";
    gethostname(hostname, sizeof(hostname));

    char logMsg[256];
    snprintf(logMsg, sizeof(logMsg), "UDP discovery listening on port %d (hostname: %s)",
             DISCOVERY_PORT, hostname);
    LogMsg(logMsg);

    char recvBuf[512];
    while (WaitForSingleObject(g_serviceStopEvent, 0) != WAIT_OBJECT_0) {
        struct sockaddr_in fromAddr;
        int fromLen = sizeof(fromAddr);

        int n = recvfrom(sock, recvBuf, sizeof(recvBuf) - 1, 0, (struct sockaddr *)&fromAddr, &fromLen);
        if (n <= 0) {
            /* timeout (expected, ~once/sec) or a transient error - just
               loop back around and check the stop event again */
            continue;
        }
        recvBuf[n] = 0;

        if (strncmp(recvBuf, DISCOVERY_REQUEST_MAGIC, strlen(DISCOVERY_REQUEST_MAGIC)) != 0) {
            continue; /* not our protocol, ignore (random UDP noise on the LAN) */
        }

        char reply[300];
        int replyLen = snprintf(reply, sizeof(reply), "%s|%s|%d",
                                 DISCOVERY_REPLY_MAGIC, hostname, CONTROL_PORT);

        sendto(sock, reply, replyLen, 0, (struct sockaddr *)&fromAddr, fromLen);

        char fromIp[64];
        strncpy(fromIp, inet_ntoa(fromAddr.sin_addr), sizeof(fromIp) - 1);
        fromIp[sizeof(fromIp) - 1] = 0;

        snprintf(logMsg, sizeof(logMsg), "UDP discovery: replied to request from %s", fromIp);
        LogMsg(logMsg);
    }

    closesocket(sock);
    LogMsg("UDP discovery thread exiting (stop requested)");
    return 0;
}

/* ---------------------------- TCP control server ---------------------------- */
/*
 * Plain-text, line-based protocol - deliberately simple, easy to test
 * by hand with a raw TCP client, no library dependencies on either side.
 *
 * Commands (one per line, newline-terminated):
 *   START_SESSION <minutes>
 *   EXTEND <minutes>
 *   PAUSE
 *   RESUME
 *   STOP
 *   GET_STATUS
 *
 * Replies (one line each):
 *   OK
 *   ERR <reason>
 *   STATUS <RUNNING|PAUSED|STOPPED> <remaining_seconds>
 */

/* Loads the optional shared secret from control_token.cfg (first line).
   Absent/empty file -> open mode + a loud warning. Called once at
   startup, before the TCP control server begins accepting. */
static void LoadControlToken(void) {
    FILE *f = fopen(g_controlTokenPath, "r");
    if (!f) {
        g_requireAuth = 0;
        LogMsg("SECURITY: no control_token.cfg found - control server is UNAUTHENTICATED. "
               "Any host on the LAN can start/extend/stop sessions. To lock it down, put a "
               "shared secret on the first line of control_token.cfg next to the exe (on every "
               "station) and have the Java server send 'AUTH <token>' before control commands.");
        return;
    }
    if (fgets(g_controlToken, sizeof(g_controlToken), f)) {
        g_controlToken[strcspn(g_controlToken, "\r\n")] = 0;
        size_t len = strlen(g_controlToken);
        while (len > 0 && (g_controlToken[len - 1] == ' ' || g_controlToken[len - 1] == '\t')) {
            g_controlToken[--len] = 0;
        }
    }
    fclose(f);

    if (g_controlToken[0]) {
        g_requireAuth = 1;
        LogMsg("Control token loaded - state-changing commands now require AUTH.");
    } else {
        g_requireAuth = 0;
        LogMsg("SECURITY: control_token.cfg is present but empty - control server left UNAUTHENTICATED.");
    }
}

/* *authed is per-connection. GET_STATUS and AUTH are always allowed;
   every state-changing command requires *authed when a token is
   configured. In open mode (no token) the handler thread pre-sets
   *authed to 1, so the gate is a no-op. */
static void HandleControlCommand(const char *line, int *authed, char *reply, int replySize) {
    int minutes;
    char token[128];

    if (sscanf(line, "AUTH %127s", token) == 1) {
        if (!g_requireAuth) {
            snprintf(reply, replySize, "OK\n");            /* auth not required */
        } else if (strcmp(token, g_controlToken) == 0) {
            *authed = 1;
            snprintf(reply, replySize, "OK\n");
        } else {
            snprintf(reply, replySize, "ERR bad token\n");
        }
        return;
    }

    if (_stricmp(line, "GET_STATUS") == 0) {
        const char *stateName;
        long remaining;
        GetStatus(&stateName, &remaining);
        snprintf(reply, replySize, "STATUS %s %ld\n", stateName, remaining);
        return;
    }

    /* Everything below changes session state - require auth. */
    if (!*authed) {
        snprintf(reply, replySize, "ERR auth required\n");
        return;
    }

    if (sscanf(line, "START_SESSION %d", &minutes) == 1) {
        if (minutes < MIN_SESSION_MINUTES || minutes > MAX_SESSION_MINUTES) {
            snprintf(reply, replySize, "ERR minutes out of range (%d..%d)\n",
                     MIN_SESSION_MINUTES, MAX_SESSION_MINUTES);
        } else {
            StartSession(minutes);
            snprintf(reply, replySize, "OK\n");
        }
    } else if (sscanf(line, "EXTEND %d", &minutes) == 1) {
        if (minutes < MIN_SESSION_MINUTES || minutes > MAX_SESSION_MINUTES) {
            snprintf(reply, replySize, "ERR minutes out of range (%d..%d)\n",
                     MIN_SESSION_MINUTES, MAX_SESSION_MINUTES);
        } else {
            ExtendSession(minutes);
            snprintf(reply, replySize, "OK\n");
        }
    } else if (_stricmp(line, "PAUSE") == 0) {
        snprintf(reply, replySize, PauseSession() ? "OK\n" : "ERR not running\n");
    } else if (_stricmp(line, "RESUME") == 0) {
        snprintf(reply, replySize, ResumeSession() ? "OK\n" : "ERR not paused\n");
    } else if (_stricmp(line, "STOP") == 0) {
        StopSession();
        snprintf(reply, replySize, "OK\n");
    } else {
        snprintf(reply, replySize, "ERR unknown command\n");
    }
}

/* Reads one line (up to a '\n'), stripping '\r'. Byte-at-a-time recv is
   fine here - this is a low-traffic control protocol (a handful of
   commands per session), not a hot path, so simplicity wins over
   efficiency. Returns line length, 0 if the peer closed the connection,
   or a negative value on error/timeout. */
static int RecvLine(SOCKET s, char *buf, int bufSize) {
    int total = 0;
    while (total < bufSize - 1) {
        char c;
        int n = recv(s, &c, 1, 0);
        if (n <= 0) return (total > 0) ? total : n;
        if (c == '\n') break;
        if (c == '\r') continue;
        buf[total++] = c;
    }
    buf[total] = 0;
    return total;
}

static DWORD WINAPI ClientHandlerThread(LPVOID param) {
    SOCKET client = (SOCKET)(UINT_PTR)param;

    /* Don't let one idle/hung connection hold a thread forever. */
    DWORD timeout = 30000;
    setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));

    /* Open mode (no token configured) -> pre-authed; otherwise the client
       must AUTH before any state-changing command is accepted. */
    int authed = g_requireAuth ? 0 : 1;

    char line[256];
    for (;;) {
        int n = RecvLine(client, line, sizeof(line));
        if (n <= 0) break; /* disconnected or timed out */

        char reply[128];
        HandleControlCommand(line, &authed, reply, sizeof(reply));
        send(client, reply, (int)strlen(reply), 0);
    }

    closesocket(client);
    InterlockedDecrement(&g_clientThreadCount);
    return 0;
}

static DWORD WINAPI TcpControlThread(LPVOID unused) {
    (void)unused;

    SOCKET listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listenSock == INVALID_SOCKET) {
        LogMsg("TCP control: socket() failed");
        return 0;
    }

    BOOL reuse = TRUE;
    setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof(reuse));

    struct sockaddr_in addr;
    ZeroMemory(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(CONTROL_PORT);

    if (bind(listenSock, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        char msg[128];
        snprintf(msg, sizeof(msg), "TCP control: bind() failed, WSAGetLastError=%d "
                                    "(port %d already in use?)", WSAGetLastError(), CONTROL_PORT);
        LogMsg(msg);
        closesocket(listenSock);
        return 0;
    }

    if (listen(listenSock, 8) == SOCKET_ERROR) {
        LogMsg("TCP control: listen() failed");
        closesocket(listenSock);
        return 0;
    }

    char logMsg[128];
    snprintf(logMsg, sizeof(logMsg), "TCP control server listening on port %d", CONTROL_PORT);
    LogMsg(logMsg);

    while (WaitForSingleObject(g_serviceStopEvent, 0) != WAIT_OBJECT_0) {
        fd_set readSet;
        FD_ZERO(&readSet);
        FD_SET(listenSock, &readSet);
        struct timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        /* select()'s first arg is ignored on Windows - poll for a
           pending connection with a 1s timeout so we notice the stop
           event promptly, same pattern as the UDP thread. */
        int sel = select(0, &readSet, NULL, NULL, &tv);
        if (sel > 0 && FD_ISSET(listenSock, &readSet)) {
            SOCKET client = accept(listenSock, NULL, NULL);
            if (client != INVALID_SOCKET) {
                /* Shed load past the cap rather than spawning unbounded
                   handler threads. The decrement happens when the handler
                   exits (or right here if we never start one). */
                if (InterlockedIncrement(&g_clientThreadCount) > CONTROL_MAX_CLIENTS) {
                    InterlockedDecrement(&g_clientThreadCount);
                    LogMsg("TCP control: connection refused - too many concurrent clients");
                    closesocket(client);
                } else {
                    HANDLE h = CreateThread(NULL, 0, ClientHandlerThread, (LPVOID)(UINT_PTR)client, 0, NULL);
                    if (h) {
                        CloseHandle(h); /* detached - handler closes its own socket + decrements */
                    } else {
                        InterlockedDecrement(&g_clientThreadCount);
                        closesocket(client);
                    }
                }
            }
        }
    }

    closesocket(listenSock);
    LogMsg("TCP control thread exiting (stop requested)");
    return 0;
}

static void WINAPI ServiceMain(DWORD argc, LPSTR *argv) {
    (void)argc; (void)argv;

    InitLogPath();
    LogMsg("ServiceMain starting");

    InitializeCriticalSection(&g_agentCs);
    LoadSessionState();
    LoadControlToken();

    g_statusHandle = RegisterServiceCtrlHandlerExA(SERVICE_NAME, ServiceCtrlHandlerEx, NULL);
    if (!g_statusHandle) {
        LogMsg("RegisterServiceCtrlHandlerEx failed");
        return;
    }

    ZeroMemory(&g_serviceStatus, sizeof(g_serviceStatus));
    g_serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    ReportServiceStatus(SERVICE_START_PENDING, NO_ERROR, 3000);

    g_serviceStopEvent = CreateEventA(NULL, TRUE, FALSE, NULL);
    if (!g_serviceStopEvent) {
        LogMsg("CreateEvent failed");
        ReportServiceStatus(SERVICE_STOPPED, GetLastError(), 0);
        return;
    }

    WSADATA wsaData;
    int wsaResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (wsaResult != 0) {
        LogMsg("WSAStartup failed - UDP discovery and TCP control will not work");
    }

    ReportServiceStatus(SERVICE_RUNNING, NO_ERROR, 0);
    LogMsg("Service running");

    g_udpThread = CreateThread(NULL, 0, UdpDiscoveryThread, NULL, 0, NULL);
    if (!g_udpThread) {
        LogMsg("Failed to start UDP discovery thread (service continues without it)");
    }

    g_tcpThread = CreateThread(NULL, 0, TcpControlThread, NULL, 0, NULL);
    if (!g_tcpThread) {
        LogMsg("Failed to start TCP control thread (service continues without it)");
    }

    g_agentSupervisorThread = CreateThread(NULL, 0, AgentSupervisorThread, NULL, 0, NULL);
    if (!g_agentSupervisorThread) {
        LogMsg("Failed to start Agent supervisor thread (service continues without it)");
    }

    RunServiceMainLoop();

    LogMsg("Service stopping");
    /* g_serviceStopEvent is already signaled by RunServiceMainLoop
       returning - both threads poll it roughly once per second, so give
       each a few seconds to notice and exit cleanly before giving up. */
    if (g_udpThread) {
        WaitForSingleObject(g_udpThread, 3000);
        CloseHandle(g_udpThread);
    }
    if (g_tcpThread) {
        WaitForSingleObject(g_tcpThread, 3000);
        CloseHandle(g_tcpThread);
    }
    if (g_agentSupervisorThread) {
        /* Wait longer than the supervisor's own 5s loop interval so it has
           fully exited before we touch the shared Agent handle below -
           the stop event wakes it immediately, so this normally returns
           in well under a second. */
        WaitForSingleObject(g_agentSupervisorThread, 7000);
        CloseHandle(g_agentSupervisorThread);
    }

    /* Reclaim the Agent handle under the lock, then act on a local copy -
       the supervisor has been joined above, so this is belt-and-suspenders
       against the pathological "supervisor still mid-launch" case. */
    EnterCriticalSection(&g_agentCs);
    HANDLE agentToKill = g_agentProcessHandle;
    g_agentProcessHandle = NULL;
    LeaveCriticalSection(&g_agentCs);
    if (agentToKill) {
        /* Clean shutdown: don't leave the Agent (and whatever it
           injected into) running with no Service behind it. All real
           session state lives in the Service anyway, so the Agent has
           nothing of its own to lose by being terminated here. */
        LogMsg("Terminating Agent process as part of service shutdown");
        TerminateProcess(agentToKill, 0);
        CloseHandle(agentToKill);
    }

    if (wsaResult == 0) WSACleanup();

    CloseHandle(g_serviceStopEvent);
    DeleteCriticalSection(&g_agentCs);
    ReportServiceStatus(SERVICE_STOPPED, NO_ERROR, 0);
}

/* ---------------------------- entry point ---------------------------- */

int main(int argc, char **argv) {
    if (argc > 1 && _stricmp(argv[1], "install") == 0) {
        return InstallService();
    }
    if (argc > 1 && _stricmp(argv[1], "uninstall") == 0) {
        return UninstallService();
    }

    /* No args: this is how the Service Control Manager itself launches
       us once installed. StartServiceCtrlDispatcher blocks until the
       service stops - it does NOT return until then. */
    SERVICE_TABLE_ENTRYA serviceTable[] = {
        { (LPSTR)SERVICE_NAME, ServiceMain },
        { NULL, NULL }
    };

    if (!StartServiceCtrlDispatcherA(serviceTable)) {
        printf("This program runs as a Windows Service and isn't meant to be\n"
               "double-clicked directly.\n\n"
               "Usage:\n"
               "  TimerService.exe install     (run as Administrator)\n"
               "  TimerService.exe uninstall   (run as Administrator)\n"
               "  sc start CafeTimer     (after installing)\n");
        return 1;
    }

    return 0;
}
