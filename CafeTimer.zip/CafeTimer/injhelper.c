/*
 * injhelper.c  ->  injhelper32.exe / injhelper64.exe
 *
 * Minimal, manifest-less "inject this DLL into this PID" helper, built in
 * BOTH bitnesses. Agent.exe launches the one whose bitness matches the
 * TARGET game, passing the matching hook DLL. Because the helper is the
 * same bitness as the target, the LoadLibraryA address it resolves is
 * valid in that target - which is what makes injecting a 32-bit hook into
 * a 32-bit game from a 64-bit Agent (and the reverse) actually work,
 * instead of silently failing with "LoadLibraryA returned NULL".
 *
 * No admin manifest on purpose: it's spawned by the non-elevated Agent
 * into the customer's own session, where same-user injection needs no
 * elevation. (A game that itself runs elevated is the known edge case -
 * the helper's OpenProcess then fails with ACCESS_DENIED, reported as
 * exit code 3.)
 *
 * Usage:  injhelper.exe <pid> <full_path_to_hook.dll>
 * Exit codes: 0 = injected OK; 2 = bad args; 3..8 as in inject_core.h.
 *
 * Build (MinGW-w64): see build.bat (built for both i686 and x86_64).
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "inject_core.h"

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <pid> <full_path_to_hook.dll>\n", argv[0]);
        return 2;
    }

    DWORD pid = (DWORD)strtoul(argv[1], NULL, 10);
    if (pid == 0) {
        printf("[!] invalid pid: %s\n", argv[1]);
        return 2;
    }

    char err[256];
    int code = InjectDllIntoPid(pid, argv[2], err, sizeof(err));
    if (code != 0) {
        printf("[!] %s\n", err);
    } else {
        printf("[+] injected %s into PID %lu\n", argv[2], pid);
    }
    return code;
}
