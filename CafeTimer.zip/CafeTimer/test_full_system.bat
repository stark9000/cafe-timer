@echo off
REM test_full_system.bat - end-to-end test of the whole pipeline:
REM   TimerService (fresh install/start) -> auto-launches Agent.exe ->
REM   Agent's desktop overlay appears -> start a session via TCP ->
REM   launch a game -> hook.dll's in-game overlay should show the SAME
REM   synced time as the desktop overlay, both fed from one Service.
REM
REM Requires ALL of these in this same folder:
REM   TimerService.exe, Agent.exe, hook.dll, games.cfg,
REM   send_tcp_command.ps1
REM Self-elevates automatically (UAC prompt).

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ============================================
echo   Full System End-to-End Test
echo ============================================
echo   This folder: %cd%
echo.

for %%F in (TimerService.exe Agent.exe hook.dll games.cfg send_tcp_command.ps1) do (
    if not exist "%%F" (
        echo [!] Missing required file: %%F
        echo     Make sure ALL required files are in this one folder.
        pause
        exit /b 1
    )
)

echo [1/6] Fresh install of TimerService from this folder...
sc stop CafeTimer >nul 2>&1
timeout /t 2 >nul
TimerService.exe uninstall >nul 2>&1
TimerService.exe install
if errorlevel 1 (
    echo [!] Install failed.
    pause
    exit /b 1
)

echo.
echo [2/6] Starting TimerService...
sc start CafeTimer
timeout /t 3 >nul
sc query CafeTimer | findstr "STATE"

echo.
echo [3/6] Waiting for the Service to auto-launch Agent.exe...
timeout /t 6 >nul
tasklist /FI "IMAGENAME eq Agent.exe" | findstr /i "Agent.exe" >nul
if errorlevel 1 (
    echo [!] Agent.exe does not appear to be running.
    echo     Check service_log.txt for "LaunchAgent" messages.
    pause
    exit /b 1
) else (
    echo [+] Agent.exe is running - the Service launched it automatically.
    echo     You should see a small "NO ACTIVE SESSION" overlay in the
    echo     top-right corner of your screen right now.
)

echo.
echo [4/6] Starting a 15-minute session...
powershell -ExecutionPolicy Bypass -File send_tcp_command.ps1 -Command "START_SESSION 15"

echo.
echo [5/6] Checking status...
powershell -ExecutionPolicy Bypass -File send_tcp_command.ps1 -Command "GET_STATUS"

echo.
echo [6/6] Manual step required:
echo ============================================
echo   The desktop overlay (top-right corner) should now be counting
echo   down from ~15:00.
echo.
echo   Now launch one of your configured games (see games.cfg).
echo   Once it's running, its in-game overlay should show the SAME
echo   countdown value as the desktop overlay - both are reading from
echo   the one TimerService, so they should always match (within a
echo   second or so, since each polls independently on its own schedule).
echo ============================================
echo.
pause
