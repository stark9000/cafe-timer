@echo off
REM manage_service.bat - install/start/stop/status/uninstall for CafeTimer
REM Self-elevates (UAC prompt) automatically if not already run as Administrator.
REM Place this next to TimerService.exe.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

:menu
cls
echo ============================================
echo   Cafe Timer - Management
echo ============================================
echo   Working folder: %cd%
echo.
echo   1. Install service  (also sets auto-start on boot)
echo   2. Start service
echo   3. Stop service
echo   4. Restart service
echo   5. Show status
echo   6. View log (last 30 lines)
echo   7. Uninstall service
echo   0. Exit
echo ============================================
set /p choice=Choose an option:

if "%choice%"=="1" goto install
if "%choice%"=="2" goto start
if "%choice%"=="3" goto stop
if "%choice%"=="4" goto restart
if "%choice%"=="5" goto status
if "%choice%"=="6" goto viewlog
if "%choice%"=="7" goto uninstall
if "%choice%"=="0" goto end
goto menu

:install
TimerService.exe install
pause
goto menu

:start
sc start CafeTimer
pause
goto menu

:stop
sc stop CafeTimer
pause
goto menu

:restart
sc stop CafeTimer
timeout /t 2 >nul
sc start CafeTimer
pause
goto menu

:status
sc query CafeTimer
pause
goto menu

:viewlog
if exist service_log.txt (
    powershell -NoProfile -Command "Get-Content -Tail 30 'service_log.txt'"
) else (
    echo service_log.txt not found yet - has the service been started?
)
pause
goto menu

:uninstall
sc stop CafeTimer >nul 2>&1
TimerService.exe uninstall
pause
goto menu

:end
exit /b
