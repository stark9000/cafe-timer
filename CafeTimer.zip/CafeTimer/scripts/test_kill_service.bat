@echo off
REM test_kill_service.bat - simulates someone force-terminating the
REM service (like a hostile admin using taskkill directly) and then
REM watches sc query to confirm Windows' auto-restart recovery actually
REM kicks in. This is a genuinely different test than "Stop Service" -
REM that path is a graceful, intentional stop and correctly does NOT
REM trigger auto-restart. This one bypasses that handshake entirely.
REM
REM Self-elevates automatically (UAC prompt) since taskkill on a SYSTEM
REM process needs Administrator rights.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================
echo   Force-kill test for CafeTimer
echo ============================================
echo.

REM Get the actual PID from the SCM itself (queryex), not tasklist -
REM more reliable if multiple things happen to share the exe name.
for /f "tokens=3" %%p in ('sc queryex CafeTimer ^| findstr /i "PID"') do set SVCPID=%%p

if "%SVCPID%"=="" (
    echo [!] Could not find a running PID for CafeTimer.
    echo     Is it installed and started? Check with: sc query CafeTimer
    pause
    exit /b 1
)

if "%SVCPID%"=="0" (
    echo [!] Service is not currently running ^(PID 0^). Start it first with:
    echo       sc start CafeTimer
    pause
    exit /b 1
)

echo [*] Current service PID: %SVCPID%
echo [*] Force-killing it now (taskkill /F), bypassing the normal stop...
taskkill /F /PID %SVCPID%

if errorlevel 1 (
    echo [!] taskkill failed - see error above.
    pause
    exit /b 1
)

echo.
echo [*] Killed. Watching sc query every 2 seconds for up to 60 seconds...
echo     Expecting: STOPPED, then RUNNING again within ~5-10 seconds
echo     ^(configured recovery delay: 5s after 1st failure^)
echo.

set /a elapsed=0
:watch
sc query CafeTimer | findstr "STATE"
sc query CafeTimer | findstr /i "RUNNING" >nul
if not errorlevel 1 (
    echo.
    echo [+] Back to RUNNING after approximately %elapsed% seconds. Recovery works.
    goto done
)

timeout /t 2 >nul
set /a elapsed=elapsed+2
if %elapsed% geq 60 (
    echo.
    echo [!] Still not RUNNING after 60 seconds - check service_log.txt
    echo     and the failure-actions config ^(sc qfailure CafeTimer^).
    goto done
)
goto watch

:done
echo.
pause
