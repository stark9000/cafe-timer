/*
 * inject_core.h
 *
 * Shared raw DLL injection (the classic VirtualAllocEx + WriteProcessMemory
 * + CreateRemoteThread(LoadLibraryA) technique), as a single header of
 * static functions so the injector tools can all share one copy instead
 * of each carrying their own.
 *
 * IMPORTANT - bitness: GetProcAddress("LoadLibraryA") here returns the
 * address in THIS process's kernel32, which is only valid in a target of
 * the SAME bitness. So the caller must be the same bitness as the target
 * process. Agent.exe guarantees this by launching the matching
 * injhelper32/64.exe for each target - see Agent.c.
 *
 * InjectDllIntoPid returns 0 on success, or a small non-zero code on
 * failure, and writes a human-readable reason into errbuf:
 *   2  (reserved for arg errors in callers)
 *   3  OpenProcess failed (often ACCESS_DENIED - target elevated)
 *   4  DLL file not found
 *   5  VirtualAllocEx failed
 *   6  WriteProcessMemory failed
 *   7  CreateRemoteThread failed
 *   8  LoadLibraryA returned NULL in target (arch mismatch / load failure)
 */
#ifndef INJECT_CORE_H
#define INJECT_CORE_H

#include <windows.h>
#include <stdio.h>
#include <string.h>

static int InjectDllIntoPid(DWORD pid, const char *dllPath, char *errbuf, size_t errsz) {
    if (GetFileAttributesA(dllPath) == INVALID_FILE_ATTRIBUTES) {
        snprintf(errbuf, errsz, "hook DLL not found at: %s", dllPath);
        return 4;
    }

    HANDLE hProc = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
                               PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
                               FALSE, pid);
    if (!hProc) {
        DWORD e = GetLastError();
        snprintf(errbuf, errsz, "OpenProcess failed (error %lu%s)", e,
                 (e == 5) ? " - ACCESS_DENIED, target may be running elevated" : "");
        return 3;
    }

    size_t pathLen = strlen(dllPath) + 1;
    LPVOID remoteMem = VirtualAllocEx(hProc, NULL, pathLen, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remoteMem) {
        snprintf(errbuf, errsz, "VirtualAllocEx failed (error %lu)", GetLastError());
        CloseHandle(hProc);
        return 5;
    }

    if (!WriteProcessMemory(hProc, remoteMem, dllPath, pathLen, NULL)) {
        snprintf(errbuf, errsz, "WriteProcessMemory failed (error %lu)", GetLastError());
        VirtualFreeEx(hProc, remoteMem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return 6;
    }

    LPTHREAD_START_ROUTINE loadLibAddr =
        (LPTHREAD_START_ROUTINE)(void *)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");

    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, loadLibAddr, remoteMem, 0, NULL);
    if (!hThread) {
        snprintf(errbuf, errsz, "CreateRemoteThread failed (error %lu)", GetLastError());
        VirtualFreeEx(hProc, remoteMem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return 7;
    }

    WaitForSingleObject(hThread, INFINITE);
    DWORD exitCode = 0;
    GetExitCodeThread(hThread, &exitCode); /* low bits of the loaded HMODULE, 0 = failed */

    CloseHandle(hThread);
    VirtualFreeEx(hProc, remoteMem, 0, MEM_RELEASE);
    CloseHandle(hProc);

    if (exitCode == 0) {
        snprintf(errbuf, errsz,
                 "LoadLibraryA returned NULL in target (arch mismatch or DLL failed to load)");
        return 8;
    }

    if (errsz) errbuf[0] = 0;
    return 0;
}

#endif /* INJECT_CORE_H */
