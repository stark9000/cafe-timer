@echo off
REM Build the 64-bit pieces. Run from an MSYS2 "MINGW64" shell (gcc = x86_64).
REM Produces: hook64.dll, injhelper64.exe, Agent.exe, TimerService.exe
REM Run from the project folder (so minhook\ resolves).

echo [64-bit] hook64.dll
gcc -shared -o hook64.dll hook.c minhook\src\*.c minhook\src\hde\*.c -Iminhook\include -ld3d9 -lgdi32 -lws2_32 -static-libgcc

echo [64-bit] injhelper64.exe
gcc injhelper.c -o injhelper64.exe -static-libgcc

echo [64-bit] Agent.exe (no admin manifest - runs at the customer's level)
gcc Agent.c -o Agent.exe -lshell32 -lws2_32 -lgdi32 -luser32 -static-libgcc

echo [64-bit] TimerService.exe
gcc TimerService.c -o TimerService.exe -ladvapi32 -lws2_32 -lwtsapi32 -luserenv -static-libgcc

echo [64-bit] done.
