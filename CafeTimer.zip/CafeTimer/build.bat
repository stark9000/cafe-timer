@echo off
REM ======================================================================
REM  Cafe Timer - full build.
REM
REM  Injection is architecture-aware, so a complete install needs BOTH
REM  bitnesses of the injected pieces (hook32/64.dll, injhelper32/64.exe).
REM
REM  Easiest path (two MSYS2 shells):
REM     MINGW32 shell:  build32.bat
REM     MINGW64 shell:  build64.bat
REM
REM  One-command path (this script): works only if BOTH cross-compilers are
REM  on PATH as i686-w64-mingw32-gcc and x86_64-w64-mingw32-gcc.
REM ======================================================================

where i686-w64-mingw32-gcc   >nul 2>&1 || goto needshells
where x86_64-w64-mingw32-gcc >nul 2>&1 || goto needshells

echo Both cross-compilers found - building everything.

echo [32] hook32.dll + injhelper32.exe + injector.exe + watcher.exe
i686-w64-mingw32-gcc -shared -o hook32.dll hook.c minhook\src\*.c minhook\src\hde\*.c -Iminhook\include -ld3d9 -lgdi32 -lws2_32 -static-libgcc
i686-w64-mingw32-gcc injhelper.c -o injhelper32.exe -static-libgcc
i686-w64-mingw32-windres admin.rc -O coff -o admin_res.o
i686-w64-mingw32-gcc injector.c admin_res.o -o injector.exe -static-libgcc
i686-w64-mingw32-gcc watcher.c  admin_res.o -o watcher.exe  -lshell32 -static-libgcc
del admin_res.o

echo [64] hook64.dll + injhelper64.exe + Agent.exe + TimerService.exe
x86_64-w64-mingw32-gcc -shared -o hook64.dll hook.c minhook\src\*.c minhook\src\hde\*.c -Iminhook\include -ld3d9 -lgdi32 -lws2_32 -static-libgcc
x86_64-w64-mingw32-gcc injhelper.c -o injhelper64.exe -static-libgcc
x86_64-w64-mingw32-gcc Agent.c -o Agent.exe -lshell32 -lws2_32 -lgdi32 -luser32 -static-libgcc
x86_64-w64-mingw32-gcc TimerService.c -o TimerService.exe -ladvapi32 -lws2_32 -lwtsapi32 -luserenv -static-libgcc

echo Done. Install folder needs: TimerService.exe, Agent.exe, hook32.dll,
echo hook64.dll, injhelper32.exe, injhelper64.exe, games.cfg (+ optional
echo control_token.cfg). injector.exe/watcher.exe are standalone manual tools.
goto :eof

:needshells
echo Both cross-compilers were not found on PATH.
echo Build each arch from its MSYS2 shell instead:
echo     MINGW32 shell:  build32.bat
echo     MINGW64 shell:  build64.bat
exit /b 1
