/*
 * Agent.c  ->  Agent.exe
 *
 * The in-session half of the cafe timer system. Detects configured
 * games and injects hook.dll into them, same core engine as the
 * earlier standalone watcher.exe. What's different from watcher.exe:
 *
 *  - No forced-admin manifest. This process is meant to eventually be
 *    launched BY TimerService.exe (running as SYSTEM) directly into the
 *    customer's own desktop session via CreateProcessAsUser - it should
 *    run at the customer's own (non-admin) privilege level, matching
 *    the games it needs to inject into. Forcing UAC here would be wrong
 *    for an auto-launched background helper - there's no one to click
 *    "Yes" on a standard account, and it isn't needed anyway since
 *    same-session, same-user processes can access each other fine
 *    without elevation (unless the target game itself runs elevated -
 *    a known edge case, not handled yet).
 *
 *  - Logs to a file (agent_log.txt next to the exe), not just stdout -
 *    once launched headlessly by the Service there's no console to see
 *    printf output in. Still prints to stdout too for now, useful while
 *    testing this standalone before the Service launches it.
 *
 *  - Does NOT relay time data anywhere. hook.dll and the (future)
 *    desktop overlay both talk directly to TimerService's TCP control
 *    server (GET_STATUS on port 47200) - the Agent's job is narrower:
 *    detect games, inject hook.dll, and (in a later step) host the
 *    desktop always-on-top overlay window. No time-tracking logic
 *    lives here at all.
 *
 * Build (MinGW-w64):
 *   gcc Agent.c -o Agent.exe -lpsapi -lshell32 -lws2_32 -lgdi32 -luser32 -static-libgcc
 *   (ws2_32 for the status/heartbeat sockets, gdi32+user32 for the
 *    desktop overlay window - the old line was missing these and would
 *    not link. build.bat has the correct invocation.)
 *
 * Usage:
 *   Agent.exe [path_to_games.cfg] [resource_dir]
 *   (both optional. resource_dir holds hook32.dll, hook64.dll,
 *    injhelper32.exe and injhelper64.exe; defaults to the Agent's folder.
 *    Injection is architecture-aware - the Agent detects each game's
 *    bitness and uses the matching hook + helper, so one Agent handles
 *    both 32- and 64-bit games.)
 *
 * games.cfg format - one entry per line, '#' for comments:
 *   exe_name.exe                                    -> detect-only
 *   exe_name.exe|C:\full\path\to\launcher_or_shortcut.exe  -> auto-launch
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdarg.h>

#define MAX_GAMES     64
#define MAX_TRACKED   256
#define POLL_MS       1000

static char g_gameNames[MAX_GAMES][MAX_PATH];
static char g_gameLaunchPaths[MAX_GAMES][MAX_PATH]; /* empty string = detect-only */
static int  g_gameCount = 0;

static DWORD g_injectedPids[MAX_TRACKED];
static int   g_injectedCount = 0;

/* Directory holding hook32.dll, hook64.dll, injhelper32.exe and
   injhelper64.exe (defaults to the folder Agent.exe runs from). */
static char g_resourceDir[MAX_PATH];
static char g_logFilePath[MAX_PATH];

/* ---------------------------- logging ---------------------------- */
/* Not performance-sensitive (this loop runs once/sec, not per-frame),
   so plain synchronous file logging is fine here - unlike hook.dll's
   render-thread hot path, there's no crash risk from a blocking write. */

static void LogMsg(const char *msg) {
    printf("%s\n", msg);

    FILE *f = fopen(g_logFilePath, "a");
    if (f) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        fprintf(f, "[%04d-%02d-%02d %02d:%02d:%02d] %s\n",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, msg);
        fclose(f);
    }
}

static void LogMsgFmt(const char *fmt, ...) {
    char buf[512];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    LogMsg(buf);
}

/* ---------------------------- games.cfg ---------------------------- */

static void LoadGameList(const char *cfgPath) {
    FILE *f = fopen(cfgPath, "r");
    if (!f) {
        LogMsgFmt("[!] Could not open %s", cfgPath);
        return;
    }
    char line[MAX_PATH * 2];
    while (fgets(line, sizeof(line), f) && g_gameCount < MAX_GAMES) {
        line[strcspn(line, "\r\n")] = 0;
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0' || *p == '#') continue;

        char *pipe = strchr(p, '|');
        if (pipe) {
            *pipe = 0;
            strncpy(g_gameNames[g_gameCount], p, MAX_PATH - 1);
            strncpy(g_gameLaunchPaths[g_gameCount], pipe + 1, MAX_PATH - 1);
        } else {
            strncpy(g_gameNames[g_gameCount], p, MAX_PATH - 1);
            g_gameLaunchPaths[g_gameCount][0] = 0;
        }
        g_gameNames[g_gameCount][MAX_PATH - 1] = 0;
        g_gameLaunchPaths[g_gameCount][MAX_PATH - 1] = 0;
        g_gameCount++;
    }
    fclose(f);

    LogMsgFmt("[+] Loaded %d game(s) from %s", g_gameCount, cfgPath);
    for (int i = 0; i < g_gameCount; i++) {
        if (g_gameLaunchPaths[i][0]) {
            LogMsgFmt("      - %s  (auto-launch: %s)", g_gameNames[i], g_gameLaunchPaths[i]);
        } else {
            LogMsgFmt("      - %s  (detect-only)", g_gameNames[i]);
        }
    }
}

static int IsProcessRunning(const char *exeName) {
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;

    int found = 0;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, exeName) == 0) { found = 1; break; }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

static void LaunchConfiguredGames(void) {
    for (int i = 0; i < g_gameCount; i++) {
        if (!g_gameLaunchPaths[i][0]) continue;

        if (IsProcessRunning(g_gameNames[i])) {
            LogMsgFmt("[*] %s is already running - not launching", g_gameNames[i]);
            continue;
        }

        LogMsgFmt("[*] Launching %s ...", g_gameLaunchPaths[i]);
        HINSTANCE result = ShellExecuteA(NULL, "open", g_gameLaunchPaths[i], NULL, NULL, SW_SHOWNORMAL);
        if ((INT_PTR)result <= 32) {
            LogMsgFmt("    [!] ShellExecute failed, code %lld - check the path in games.cfg",
                      (long long)(INT_PTR)result);
        }
    }
}

static int IsConfiguredGame(const char *exeName) {
    for (int i = 0; i < g_gameCount; i++) {
        if (_stricmp(exeName, g_gameNames[i]) == 0) return 1;
    }
    return 0;
}

static int IsAlreadyInjected(DWORD pid) {
    for (int i = 0; i < g_injectedCount; i++) {
        if (g_injectedPids[i] == pid) return 1;
    }
    return 0;
}

static void RememberInjected(DWORD pid) {
    if (g_injectedCount < MAX_TRACKED) {
        g_injectedPids[g_injectedCount++] = pid;
    }
}

static void PruneDeadPids(void) {
    int writeIdx = 0;
    for (int i = 0; i < g_injectedCount; i++) {
        HANDLE h = OpenProcess(SYNCHRONIZE, FALSE, g_injectedPids[i]);
        int alive = 0;
        if (h) {
            alive = (WaitForSingleObject(h, 0) == WAIT_TIMEOUT);
            CloseHandle(h);
        }
        if (alive) g_injectedPids[writeIdx++] = g_injectedPids[i];
    }
    g_injectedCount = writeIdx;
}

/* ---------------------------- injection ---------------------------- */
/*
 * Injection is architecture-aware. A process can only be injected into by
 * a tool of its OWN bitness (the LoadLibraryA address used for the remote
 * thread must be valid in the target), so the Agent never injects
 * directly. Instead it:
 *   1. detects the TARGET game's bitness, then
 *   2. launches the matching injhelper32/64.exe with the matching
 *      hook32/64.dll.
 * This makes a single 64-bit Agent able to service both 64-bit games
 * (directly matched) and 32-bit games like the C&C titles (via the 32-bit
 * helper) - the previous code just injected one fixed-bitness hook.dll and
 * logged a failure on any mismatch.
 *
 * All four files (hook32.dll, hook64.dll, injhelper32.exe, injhelper64.exe)
 * must sit in the resource directory (next to Agent.exe by default).
 */

/* 1 = 32-bit target, 0 = 64-bit target, -1 = couldn't determine.
   Prefers IsWow64Process2 (Win10+), which reports the process image
   machine and the native machine and so resolves bitness correctly on
   x64 and ARM64 alike; falls back to IsWow64Process + GetNativeSystemInfo
   on older Windows. */
static int TargetIs32Bit(DWORD pid) {
    HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!h) h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!h) return -1;

    int result = -1;

    typedef BOOL (WINAPI *IsWow64Process2_t)(HANDLE, USHORT *, USHORT *);
    IsWow64Process2_t pIsWow64Process2 =
        (IsWow64Process2_t)(void *)GetProcAddress(GetModuleHandleA("kernel32.dll"), "IsWow64Process2");

    if (pIsWow64Process2) {
        USHORT procMachine = 0, nativeMachine = 0;
        if (pIsWow64Process2(h, &procMachine, &nativeMachine)) {
            /* procMachine == UNKNOWN means "runs as the native machine";
               otherwise it's the emulated image machine (e.g. I386). */
            USHORT eff = (procMachine == IMAGE_FILE_MACHINE_UNKNOWN) ? nativeMachine : procMachine;
            result = (eff == IMAGE_FILE_MACHINE_I386) ? 1 : 0;
        }
    } else {
        BOOL wow = FALSE;
        if (IsWow64Process(h, &wow)) {
            SYSTEM_INFO si;
            GetNativeSystemInfo(&si);
            if (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_INTEL) {
                result = 1;              /* 32-bit OS - everything is 32-bit */
            } else {
                result = wow ? 1 : 0;    /* 64-bit OS: WOW64 => 32-bit process */
            }
        }
    }

    CloseHandle(h);
    return result;
}

static int InjectDll(DWORD pid, const char *exeName) {
    int is32 = TargetIs32Bit(pid);
    if (is32 < 0) {
        LogMsgFmt("    [!] Could not determine bitness of %s (PID %lu) - skipping", exeName, pid);
        return 0;
    }
    const char *bits = is32 ? "32" : "64";

    char hookPath[MAX_PATH], helperPath[MAX_PATH];
    snprintf(hookPath, sizeof(hookPath), "%shook%s.dll", g_resourceDir, bits);
    snprintf(helperPath, sizeof(helperPath), "%sinjhelper%s.exe", g_resourceDir, bits);

    if (GetFileAttributesA(hookPath) == INVALID_FILE_ATTRIBUTES) {
        LogMsgFmt("    [!] %s is a %s-bit game but %s is missing - "
                  "put the %s-bit hook next to Agent.exe", exeName, bits, hookPath, bits);
        return 0;
    }
    if (GetFileAttributesA(helperPath) == INVALID_FILE_ATTRIBUTES) {
        LogMsgFmt("    [!] %s is a %s-bit game but %s is missing - "
                  "put the %s-bit injector helper next to Agent.exe", exeName, bits, helperPath, bits);
        return 0;
    }

    char cmdLine[MAX_PATH * 2 + 64];
    snprintf(cmdLine, sizeof(cmdLine), "\"%s\" %lu \"%s\"", helperPath, pid, hookPath);

    STARTUPINFOA si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));

    if (!CreateProcessA(NULL, cmdLine, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        LogMsgFmt("    [!] Failed to launch %s (error %lu)", helperPath, GetLastError());
        return 0;
    }

    /* Injection is near-instant (LoadLibraryA returns once our DllMain
       returns, which spawns its own worker and returns immediately). Cap
       the wait so a pathological target can't stall the scan loop. */
    WaitForSingleObject(pi.hProcess, 15000);
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);

    if (code == 0) {
        LogMsgFmt("    [+] %s-bit helper injected hook%s.dll into %s", bits, bits, exeName);
        return 1;
    }
    LogMsgFmt("    [!] %s-bit helper failed (exit %lu) injecting into %s", bits, code, exeName);
    return 0;
}

static void ScanAndInject(void) {
    enum { SCAN_BATCH = 16 }; /* far more concurrent games than ever realistic */
    DWORD pids[SCAN_BATCH];
    char  names[SCAN_BATCH][MAX_PATH];
    int   count = 0;

    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return;

    /* Collect matching targets first, then release the snapshot BEFORE
       any slow work. Previously the 1.5s settle wait + the whole
       injection ran while still holding the toolhelp snapshot and inside
       the enumeration loop - pure stall, with two matches costing 3s per
       poll. The snapshot is a point-in-time copy, so nothing is lost by
       releasing it before we act on what we found. */
    if (Process32First(snap, &pe)) {
        do {
            if (!IsConfiguredGame(pe.szExeFile)) continue;
            if (IsAlreadyInjected(pe.th32ProcessID)) continue;
            if (count >= SCAN_BATCH) break;
            pids[count] = pe.th32ProcessID;
            strncpy(names[count], pe.szExeFile, MAX_PATH - 1);
            names[count][MAX_PATH - 1] = 0;
            count++;
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);

    for (int i = 0; i < count; i++) {
        LogMsgFmt("[+] Detected %s (PID %lu) - injecting...", names[i], pids[i]);

        Sleep(1500); /* let the game finish its own early init first */

        if (InjectDll(pids[i], names[i])) {
            LogMsgFmt("[+] Injected into %s successfully", names[i]);
        } else {
            LogMsgFmt("[!] Injection into %s failed", names[i]);
        }
        RememberInjected(pids[i]); /* remember either way - don't retry-spam */
    }
}

/* ---------------------------- desktop overlay ---------------------------- */
/*
 * Always-on-top window showing the current session time, visible on the
 * desktop/over other apps whenever a game isn't covering the screen in
 * true exclusive fullscreen (same DWM limitation discussed for the
 * in-game overlay - nothing can be composited over exclusive fullscreen
 * from outside the game process, which is fine here since that's
 * exactly when the in-game hook.dll overlay is showing the time instead).
 *
 * Talks DIRECTLY to TimerService's TCP control server - no relay
 * through anything else. A background thread polls GET_STATUS once a
 * second and updates a couple of shared variables; the window's own
 * thread only ever reads those variables to repaint, it never touches
 * the network itself - same non-blocking-render discipline as hook.dll,
 * just for the desktop window's message loop instead of a D3D render
 * loop, but the principle (never block the thing that has to stay
 * responsive) is identical.
 */

#define CONTROL_PORT 47200

#define AGENT_STATE_UNKNOWN -1
#define AGENT_STATE_STOPPED  0
#define AGENT_STATE_RUNNING  1
#define AGENT_STATE_PAUSED   2

static volatile LONG g_overlayState = AGENT_STATE_UNKNOWN;
static volatile LONG g_overlayRemainingSec = 0;
static volatile LONG g_overlayConnected = 0;

/* Fed by HeartbeatListenerThread below - tracks the last time a
   hook.dll instance reported it was actively drawing an in-game
   overlay. The desktop overlay hides itself while this is recent, and
   reappears once it goes stale (game closed, hook stopped drawing,
   etc) - this is "Option B" from the design discussion: hide based on
   CONFIRMED active drawing, not just "a game process exists", so a
   silent injection failure still leaves the desktop overlay as a
   working fallback instead of neither overlay showing at all. */
#define HOOK_HEARTBEAT_PORT 47300
#define HOOK_HEARTBEAT_STALE_MS 2500
static volatile LONG g_lastHeartbeatTick = 0;

static char g_overlayPosFilePath[MAX_PATH];

/* One-shot query: connect, send GET_STATUS, read the reply, disconnect.
   Short-lived connections keep this simple and robust - no persistent-
   connection reconnect logic needed, at the cost of one connect/sec,
   which is negligible on localhost. */
/* Reads one newline-terminated line, stripping '\r'. A single recv()
   isn't guaranteed to return the whole reply even on localhost, so read
   to the newline rather than assuming one packet == one line. SO_RCVTIMEO
   is already set, so a stalled peer can't block us forever. Returns line
   length, 0 if the peer closed, or <0 on error/timeout. */
static int RecvLineSock(SOCKET s, char *buf, int bufSize) {
    int total = 0;
    while (total < bufSize - 1) {
        char c;
        int n = recv(s, &c, 1, 0);
        if (n <= 0) return (total > 0) ? total : n;
        if (c == '\n') break;
        if (c == '\r') continue;
        buf[total++] = c;
    }
    buf[total] = 0;
    return total;
}

static void PollStatusOnce(void) {
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return;

    DWORD timeout = 2000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout));

    struct sockaddr_in addr;
    ZeroMemory(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CONTROL_PORT);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        closesocket(s);
        InterlockedExchange(&g_overlayConnected, 0);
        return;
    }

    const char *cmd = "GET_STATUS\n";
    if (send(s, cmd, (int)strlen(cmd), 0) == SOCKET_ERROR) {
        closesocket(s);
        InterlockedExchange(&g_overlayConnected, 0);
        return;
    }

    char buf[128];
    int n = RecvLineSock(s, buf, sizeof(buf));
    closesocket(s);

    if (n <= 0) {
        InterlockedExchange(&g_overlayConnected, 0);
        return;
    }

    char stateStr[32];
    long remaining = 0;
    if (sscanf(buf, "STATUS %31s %ld", stateStr, &remaining) == 2) {
        int stateVal = AGENT_STATE_UNKNOWN;
        if (_stricmp(stateStr, "RUNNING") == 0) stateVal = AGENT_STATE_RUNNING;
        else if (_stricmp(stateStr, "PAUSED") == 0) stateVal = AGENT_STATE_PAUSED;
        else if (_stricmp(stateStr, "STOPPED") == 0) stateVal = AGENT_STATE_STOPPED;

        InterlockedExchange(&g_overlayState, stateVal);
        InterlockedExchange(&g_overlayRemainingSec, remaining);
        InterlockedExchange(&g_overlayConnected, 1);
    } else {
        InterlockedExchange(&g_overlayConnected, 0);
    }
}

static DWORD WINAPI StatusPollThread(LPVOID unused) {
    (void)unused;
    for (;;) {
        PollStatusOnce();
        Sleep(1000);
    }
    return 0;
}

/* Listens (loopback only - these pings only ever come from a hook.dll
   injected into a game on this same machine) for fire-and-forget UDP
   heartbeats from any running hook.dll instance. No reply needed, no
   connection state - just "update the last-seen tick if this looks
   like our heartbeat". */
static DWORD WINAPI HeartbeatListenerThread(LPVOID unused) {
    (void)unused;

    SOCKET sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET) return 0;

    struct sockaddr_in addr;
    ZeroMemory(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_port = htons(HOOK_HEARTBEAT_PORT);

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        LogMsgFmt("[!] Heartbeat listener bind() failed, WSAGetLastError=%d", WSAGetLastError());
        closesocket(sock);
        return 0;
    }

    DWORD timeout = 1000;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));

    char buf[32];
    for (;;) {
        struct sockaddr_in from;
        int fromLen = sizeof(from);
        int n = recvfrom(sock, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&from, &fromLen);
        if (n > 0) {
            buf[n] = 0;
            if (strncmp(buf, "HOOK_ALIVE", 10) == 0) {
                InterlockedExchange(&g_lastHeartbeatTick, (LONG)GetTickCount());
            }
        }
        /* timeout (expected, ~once/sec) or noise - loop again */
    }
    return 0;
}

/* ---------------------------- overlay position persistence ---------------------------- */

static void LoadOverlayPosition(int *x, int *y, int defaultX, int defaultY) {
    *x = defaultX;
    *y = defaultY;

    FILE *f = fopen(g_overlayPosFilePath, "r");
    if (!f) return;

    int fx, fy;
    if (fscanf(f, "%d %d", &fx, &fy) == 2) {
        *x = fx;
        *y = fy;
    }
    fclose(f);
}

static void SaveOverlayPosition(int x, int y) {
    FILE *f = fopen(g_overlayPosFilePath, "w");
    if (f) {
        fprintf(f, "%d %d\n", x, y);
        fclose(f);
    }
}

static void FormatOverlayText(char *out, size_t outSize) {
    int connected = (int)InterlockedCompareExchange(&g_overlayConnected, 0, 0);
    if (!connected) {
        snprintf(out, outSize, "TIMER: connecting...");
        return;
    }

    int state = (int)InterlockedCompareExchange(&g_overlayState, 0, 0);
    long remaining = (long)InterlockedCompareExchange(&g_overlayRemainingSec, 0, 0);
    if (remaining < 0) remaining = 0;

    long h = remaining / 3600, m = (remaining / 60) % 60, s = remaining % 60;

    switch (state) {
        case AGENT_STATE_RUNNING:
            snprintf(out, outSize, "%02ld:%02ld:%02ld", h, m, s);
            break;
        case AGENT_STATE_PAUSED:
            snprintf(out, outSize, "PAUSED  %02ld:%02ld:%02ld", h, m, s);
            break;
        default:
            snprintf(out, outSize, "NO ACTIVE SESSION");
            break;
    }
}

#define OVERLAY_WIDTH  220
#define OVERLAY_HEIGHT 54

static LRESULT CALLBACK OverlayWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_TIMER: {
            /* Some apps/games fight for topmost - keep re-asserting it,
               same technique discussed for the very first overlay idea
               back at the start of this project. */
            SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

            DWORD lastBeat = (DWORD)InterlockedCompareExchange(&g_lastHeartbeatTick, 0, 0);
            DWORD now = GetTickCount();
            int hookActive = (lastBeat != 0) && ((now - lastBeat) < HOOK_HEARTBEAT_STALE_MS);

            if (hookActive) {
                /* The in-game overlay is confirmed actively drawing right
                   now - showing this one too would just be a redundant
                   second timer on screen, which is the whole problem
                   being fixed here. */
                ShowWindow(hwnd, SW_HIDE);
            } else {
                ShowWindow(hwnd, SW_SHOWNOACTIVATE);
                InvalidateRect(hwnd, NULL, FALSE);
            }
            return 0;
        }
        case WM_LBUTTONDOWN: {
            /* Standard borderless-window drag trick: tell Windows to
               treat this click as if it landed on a title bar, which
               makes the whole window draggable from anywhere on it
               without us implementing manual mouse-delta tracking. */
            ReleaseCapture();
            SendMessage(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            return 0;
        }
        case WM_EXITSIZEMOVE: {
            /* Fired when a drag-move (via the HTCAPTION trick above)
               finishes - persist the new position so it's remembered
               next time Agent.exe starts. */
            RECT rc;
            GetWindowRect(hwnd, &rc);
            SaveOverlayPosition(rc.left, rc.top);
            return 0;
        }
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            RECT rc;
            GetClientRect(hwnd, &rc);

            HBRUSH bg = CreateSolidBrush(RGB(15, 15, 15));
            FillRect(hdc, &rc, bg);
            DeleteObject(bg);

            char text[64];
            FormatOverlayText(text, sizeof(text));

            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, RGB(255, 255, 255));

            /* Same font every repaint (twice a second) - build it once and
               keep it for the life of the process. Only ever used on this
               (overlay window) thread. */
            static HFONT s_font = NULL;
            if (!s_font) {
                s_font = CreateFontA(22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                     DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                     CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
            }
            HFONT oldFont = s_font ? (HFONT)SelectObject(hdc, s_font) : NULL;

            DrawTextA(hdc, text, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            if (oldFont) SelectObject(hdc, oldFont);

            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProcA(hwnd, msg, wParam, lParam);
    }
}

static DWORD WINAPI OverlayWindowThread(LPVOID unused) {
    (void)unused;

    HANDLE heartbeatThread = CreateThread(NULL, 0, HeartbeatListenerThread, NULL, 0, NULL);
    if (heartbeatThread) CloseHandle(heartbeatThread);

    WNDCLASSA wc;
    ZeroMemory(&wc, sizeof(wc));
    wc.lpfnWndProc = OverlayWndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = "CafeTimerOverlay";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClassA(&wc);

    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int defaultX = screenW - OVERLAY_WIDTH - 20;
    int defaultY = 20;

    int x, y;
    LoadOverlayPosition(&x, &y, defaultX, defaultY);

    /* WS_EX_TOPMOST: stays above other windows.
       WS_EX_TOOLWINDOW: no taskbar button, doesn't show in Alt+Tab.
       WS_EX_LAYERED: needed for SetLayeredWindowAttributes (slight
       transparency below) - also lets DWM composite it efficiently.
       No WS_EX_TRANSPARENT anymore - click-through was removed so the
       window can be dragged to a comfortable position; the tradeoff is
       a customer COULD click it (there's nothing harmful behind a
       click other than starting a drag, so this is an acceptable trade). */
    HWND hwnd = CreateWindowExA(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED,
        "CafeTimerOverlay", "Cafe Timer",
        WS_POPUP,
        x, y, OVERLAY_WIDTH, OVERLAY_HEIGHT,
        NULL, NULL, GetModuleHandle(NULL), NULL);

    if (!hwnd) return 0;

    SetLayeredWindowAttributes(hwnd, 0, 235, LWA_ALPHA); /* slightly transparent */
    ShowWindow(hwnd, SW_SHOWNOACTIVATE);
    SetTimer(hwnd, 1, 500, NULL); /* repaint + re-assert topmost twice/sec */

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}

/* ---------------------------- entry point ---------------------------- */

int main(int argc, char **argv) {
    char exeDir[MAX_PATH];
    GetModuleFileNameA(NULL, exeDir, MAX_PATH);
    char *lastSlash = strrchr(exeDir, '\\');
    if (lastSlash) *(lastSlash + 1) = 0;

    snprintf(g_logFilePath, MAX_PATH, "%sagent_log.txt", exeDir);
    snprintf(g_overlayPosFilePath, MAX_PATH, "%soverlay_position.txt", exeDir);

    char cfgPath[MAX_PATH];
    if (argc > 1) {
        strncpy(cfgPath, argv[1], MAX_PATH - 1);
        cfgPath[MAX_PATH - 1] = 0;
    } else {
        snprintf(cfgPath, MAX_PATH, "%sgames.cfg", exeDir);
    }

    /* Optional 2nd arg: directory holding hook32/64.dll + injhelper32/64.exe.
       Defaults to the Agent's own folder. A trailing backslash is ensured
       so the "%s<file>" concatenations resolve correctly. */
    if (argc > 2) {
        strncpy(g_resourceDir, argv[2], MAX_PATH - 1);
        g_resourceDir[MAX_PATH - 1] = 0;
        size_t rlen = strlen(g_resourceDir);
        if (rlen > 0 && g_resourceDir[rlen - 1] != '\\' && rlen < MAX_PATH - 1) {
            g_resourceDir[rlen] = '\\';
            g_resourceDir[rlen + 1] = 0;
        }
    } else {
        strncpy(g_resourceDir, exeDir, MAX_PATH - 1);
        g_resourceDir[MAX_PATH - 1] = 0;
    }

    LogMsg("[*] Agent started.");
    LogMsgFmt("[*] Config:    %s", cfgPath);
    LogMsgFmt("[*] Resources: %s (hook32/64.dll + injhelper32/64.exe)", g_resourceDir);

    LoadGameList(cfgPath);
    if (g_gameCount == 0) {
        LogMsg("[!] No games configured - nothing to watch for. Exiting.");
        return 1;
    }

    LogMsg("[*] Watching for configured games (Ctrl+C to stop)...");

    LaunchConfiguredGames();

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        LogMsg("[!] WSAStartup failed - desktop overlay will show 'connecting...' forever");
    }

    HANDLE pollThread = CreateThread(NULL, 0, StatusPollThread, NULL, 0, NULL);
    if (pollThread) CloseHandle(pollThread);
    else LogMsg("[!] Failed to start status-poll thread");

    HANDLE overlayThread = CreateThread(NULL, 0, OverlayWindowThread, NULL, 0, NULL);
    if (overlayThread) CloseHandle(overlayThread);
    else LogMsg("[!] Failed to start desktop overlay thread");

    while (1) {
        PruneDeadPids();
        ScanAndInject();
        Sleep(POLL_MS);
    }

    return 0;
}
