@echo off
powershell.exe -ExecutionPolicy Bypass -Command "& '.\send_tcp_command.ps1' -Command 'STOP'"
pause