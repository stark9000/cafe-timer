/*
 * hook.c  ->  hook.dll
 *
 * D3D9 overlay: MinHook inline hook on EndScene (see header comment
 * history in README for why inline hooking, not a vtable swap), drawing
 * via a GDI-rendered texture instead of IDirect3DSurface9::GetDC on the
 * back buffer directly.
 *
 * Why a texture instead of drawing straight on the back buffer:
 * IDirect3DSurface9::GetDC FAILS (D3DERR_INVALIDCALL) whenever the back
 * buffer is multisampled (anti-aliasing on) - confirmed hitting exactly
 * this testing against C&C3. A D3DPOOL_SYSTEMMEM offscreen surface is
 * never multisampled, so GetDC on THAT always works regardless of the
 * game's AA setting. So the pipeline is:
 *
 *   1. (once) Create a small D3DPOOL_DEFAULT texture + a same-sized
 *      D3DPOOL_SYSTEMMEM offscreen surface.
 *   2. (once per second, since our timer only changes once a second)
 *      GetDC on the offscreen surface, draw the timer text with plain
 *      GDI TextOut, ReleaseDC, then IDirect3DDevice9::UpdateSurface to
 *      copy it into the texture.
 *   3. (every frame) draw that texture as a pre-transformed
 *      (D3DFVF_XYZRHW) screen-space quad with DrawPrimitiveUP - this is
 *      normal D3D9 drawing, completely unaffected by back-buffer AA.
 *      Render states we touch are saved before and restored after, so
 *      we don't corrupt whatever state the game's own renderer expects
 *      next frame.
 *
 * Build (MinGW-w64): see build.bat - it compiles this together with the
 * MinHook sources (minhook src + hde) and links d3d9, gdi32 and ws2_32.
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <d3d9.h>
#include <stdio.h>
#include <stdarg.h>
#include "minhook/include/MinHook.h"

#define WATCHDOG_TIMEOUT_MS 5000   /* overridden by config file if present */
#define OVERLAY_TEX_W 220
#define OVERLAY_TEX_H 40

static char g_configFilePath[MAX_PATH];
static char g_logFilePath[MAX_PATH];

/* ---------- non-blocking logger ----------
   LogMsg/LogMsgFmt used to do a synchronous fopen/fwrite/fclose on every
   call. That's real, unpredictable latency (disk I/O, NTFS metadata)
   landing right in the middle of the device-lost/reset window - a
   likely contributor to the crash. Now they just append to an in-memory
   ring buffer under a lightweight critical section, and a background
   thread flushes it to disk periodically. The hot path (hook functions)
   never touches the filesystem directly anymore. */
#define LOG_BUFFER_SIZE 16384
static CRITICAL_SECTION g_logCs;
static char g_logBuffer[LOG_BUFFER_SIZE];
static int g_logLen = 0;
static int g_logCsReady = 0;

static void LogMsg(const char *msg) {
    if (!g_logCsReady) return; /* too early / not initialized yet - drop silently */

    char line[300];
    int lineLen = wsprintfA(line, "[%lu] %s\r\n", GetTickCount(), msg);

    EnterCriticalSection(&g_logCs);
    if (g_logLen + lineLen < LOG_BUFFER_SIZE) {
        memcpy(g_logBuffer + g_logLen, line, lineLen);
        g_logLen += lineLen;
    }
    /* else: buffer full, drop the message rather than block or grow -
       logging must never be allowed to stall the render/recovery path */
    LeaveCriticalSection(&g_logCs);
}

static void FlushLogToDisk(void) {
    if (!g_logCsReady) return;

    EnterCriticalSection(&g_logCs);
    int len = g_logLen;
    if (len > 0) {
        char *copy = (char *)malloc(len);
        if (copy) memcpy(copy, g_logBuffer, len);
        g_logLen = 0;
        LeaveCriticalSection(&g_logCs);

        if (copy) {
            FILE *f = fopen(g_logFilePath, "a");
            if (f) { fwrite(copy, 1, len, f); fclose(f); }
            free(copy);
        }
    } else {
        LeaveCriticalSection(&g_logCs);
    }
}

static DWORD WINAPI LogFlushThread(LPVOID unused) {
    (void)unused;
    while (1) {
        Sleep(500);
        FlushLogToDisk();
    }
    return 0;
}

static void InitPaths(HMODULE hModule) {
    char selfPath[MAX_PATH];
    GetModuleFileNameA(hModule, selfPath, MAX_PATH);
    char *lastSlash = strrchr(selfPath, '\\');
    if (lastSlash) *(lastSlash + 1) = 0;
    snprintf(g_logFilePath, MAX_PATH, "%shook_log.txt", selfPath);
    snprintf(g_configFilePath, MAX_PATH, "%stimeout.cfg", selfPath);

    InitializeCriticalSection(&g_logCs);
    g_logCsReady = 1;

    HANDLE flushThread = CreateThread(NULL, 0, LogFlushThread, NULL, 0, NULL);
    if (flushThread) CloseHandle(flushThread);
}

typedef HRESULT (WINAPI *EndScene_t)(LPDIRECT3DDEVICE9);
static EndScene_t oEndScene = NULL;
typedef HRESULT (WINAPI *Reset_t)(LPDIRECT3DDEVICE9, D3DPRESENT_PARAMETERS *);
static Reset_t oReset = NULL;
typedef HRESULT (WINAPI *ResetEx_t)(LPDIRECT3DDEVICE9, D3DPRESENT_PARAMETERS *, D3DDISPLAYMODEEX *);
static ResetEx_t oResetEx = NULL;
typedef HRESULT (WINAPI *TestCoopLevel_t)(LPDIRECT3DDEVICE9);
static TestCoopLevel_t oTestCoopLevel = NULL;

/* Tracks whether the device is currently believed healthy, updated by
   hkTestCoopLevel. hkEndScene skips ALL overlay work (texture creation,
   update, draw) whenever this is false - we do zero extra GPU work
   while the device is lost/not-reset, which is exactly the window where
   any added latency risks blowing through the engine's own recovery
   budget (this is what caused the crash: our hooks were doing file I/O
   and full draw work during that exact window). */
static volatile LONG g_deviceOk = 1;

static void LogMsgFmt(const char *fmt, ...) {
    char buf[256];
    va_list args;
    va_start(args, fmt);
    wvsprintfA(buf, fmt, args);
    va_end(args);
    LogMsg(buf);
}

static DWORD ReadConfiguredTimeout(void) {
    FILE *f = fopen(g_configFilePath, "r");
    if (!f) return WATCHDOG_TIMEOUT_MS;
    int ms = 0;
    if (fscanf(f, "%d", &ms) != 1 || ms <= 0) ms = WATCHDOG_TIMEOUT_MS;
    fclose(f);
    return (DWORD)ms;
}

/* ---------- overlay texture (GDI-rendered, AA-independent) ---------- */

typedef struct { float x, y, z, rhw; D3DCOLOR color; float u, v; } OverlayVertex;
#define OVERLAY_FVF (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

static IDirect3DTexture9 *g_overlayTex = NULL;
static IDirect3DSurface9 *g_overlaySysSurface = NULL;
static int g_overlayTexReady = 0;
static int g_overlayTexFailed = 0;
static char g_lastRenderedText[64] = "";

static int EnsureOverlayTexture(LPDIRECT3DDEVICE9 device) {
    if (g_overlayTexReady || g_overlayTexFailed) return g_overlayTexReady;

    HRESULT hr = IDirect3DDevice9_CreateTexture(device, OVERLAY_TEX_W, OVERLAY_TEX_H, 1, 0,
                                                 D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &g_overlayTex, NULL);
    if (FAILED(hr)) {
        LogMsgFmt("CreateTexture failed hr=0x%08lx", hr);
        g_overlayTexFailed = 1;
        return 0;
    }

    hr = IDirect3DDevice9_CreateOffscreenPlainSurface(device, OVERLAY_TEX_W, OVERLAY_TEX_H,
                                                        D3DFMT_A8R8G8B8, D3DPOOL_SYSTEMMEM,
                                                        &g_overlaySysSurface, NULL);
    if (FAILED(hr)) {
        LogMsgFmt("CreateOffscreenPlainSurface failed hr=0x%08lx", hr);
        IDirect3DTexture9_Release(g_overlayTex);
        g_overlayTex = NULL;
        g_overlayTexFailed = 1;
        return 0;
    }

    LogMsg("Overlay texture + system-memory surface created");
    g_overlayTexReady = 1;
    return 1;
}

static void RenderTextToOverlay(LPDIRECT3DDEVICE9 device, const char *text) {
    HDC hdc;
    /* This GetDC call is on a SYSTEMMEM offscreen surface, never
       multisampled - unlike the back buffer, this always works. */
    if (FAILED(IDirect3DSurface9_GetDC(g_overlaySysSurface, &hdc))) {
        LogMsg("GetDC on system-memory overlay surface failed (unexpected)");
        return;
    }

    RECT r = { 0, 0, OVERLAY_TEX_W, OVERLAY_TEX_H };
    HBRUSH bg = CreateSolidBrush(RGB(10, 10, 10));
    FillRect(hdc, &r, bg);
    DeleteObject(bg);

    /* Font is identical every call - create it once and keep it for the
       life of the process instead of building/destroying a GDI object
       every second. Only ever touched on this (render) thread. */
    static HFONT s_font = NULL;
    if (!s_font) {
        s_font = CreateFontA(22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                             DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    }
    HFONT oldFont = s_font ? (HFONT)SelectObject(hdc, s_font) : NULL;

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 255, 255));
    TextOutA(hdc, 8, 8, text, (int)strlen(text));

    if (oldFont) SelectObject(hdc, oldFont);

    IDirect3DSurface9_ReleaseDC(g_overlaySysSurface, hdc);

    IDirect3DSurface9 *destSurface = NULL;
    if (SUCCEEDED(IDirect3DTexture9_GetSurfaceLevel(g_overlayTex, 0, &destSurface))) {
        HRESULT hr = IDirect3DDevice9_UpdateSurface(device, g_overlaySysSurface, NULL, destSurface, NULL);
        if (FAILED(hr)) LogMsgFmt("UpdateSurface failed hr=0x%08lx", hr);
        IDirect3DSurface9_Release(destSurface);
    }
}

/* ---------------------------- status polling (networking) ---------------------------- */
/*
 * Replaces the old "elapsed time since injection" local computation
 * with the real, authoritative session time from TimerService's TCP
 * control server - the same GET_STATUS the desktop overlay uses. No
 * relay through the Agent; this connects directly, just like the
 * desktop overlay does.
 *
 * CRITICAL RULE: nothing here may ever block hkEndScene / the D3D
 * render thread. All networking happens on its own background thread;
 * hkEndScene only ever reads a couple of shared variables that thread
 * updates. This is the same class of mistake that caused the C&C3
 * device-reset crash earlier in this project (blocking file I/O that
 * time, blocking sockets now) - a single blocking call at the wrong
 * moment can stall or crash the game's own render thread. Short-lived
 * connections (connect, ask, read, disconnect) with short timeouts,
 * once a second, on a background thread only.
 */

#define CONTROL_PORT 47200

/* Fire-and-forget "I'm actively drawing" ping to Agent.exe's desktop
   overlay, so it hides itself while this in-game overlay is visible
   (otherwise both show at once in windowed/borderless). Sent from the
   background poll thread - NEVER the render thread - whenever a frame
   was drawn recently. g_lastDrawTick is stamped by hkEndScene after a
   successful draw; the poll thread reads it and pings if it's fresh. */
#define HOOK_HEARTBEAT_PORT 47300
#define HOOK_DRAW_FRESH_MS  2000
static volatile LONG g_lastDrawTick = 0;

#define HOOK_STATE_UNKNOWN -1
#define HOOK_STATE_STOPPED  0
#define HOOK_STATE_RUNNING  1
#define HOOK_STATE_PAUSED   2

static volatile LONG g_hookState = HOOK_STATE_UNKNOWN;
static volatile LONG g_hookRemainingSec = 0;
static volatile LONG g_hookConnected = 0;

/* Reads one newline-terminated line, stripping '\r'. A single recv()
   isn't guaranteed to return the whole reply even on localhost, so read
   to the newline instead of assuming one packet == one line. The socket
   already has SO_RCVTIMEO set, so a stalled peer can't block us forever.
   Returns line length, 0 if the peer closed, or <0 on error/timeout. */
static int RecvLineSock(SOCKET s, char *buf, int bufSize) {
    int total = 0;
    while (total < bufSize - 1) {
        char c;
        int n = recv(s, &c, 1, 0);
        if (n <= 0) return (total > 0) ? total : n;
        if (c == '\n') break;
        if (c == '\r') continue;
        buf[total++] = c;
    }
    buf[total] = 0;
    return total;
}

static void PollStatusOnce(void) {
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return;

    DWORD timeout = 2000; /* generous but bounded - this is on our own
                              background thread, never the render thread */
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout));

    struct sockaddr_in addr;
    ZeroMemory(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CONTROL_PORT);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        closesocket(s);
        InterlockedExchange(&g_hookConnected, 0);
        return;
    }

    const char *cmd = "GET_STATUS\n";
    if (send(s, cmd, (int)strlen(cmd), 0) == SOCKET_ERROR) {
        closesocket(s);
        InterlockedExchange(&g_hookConnected, 0);
        return;
    }

    char buf[128];
    int n = RecvLineSock(s, buf, sizeof(buf));
    closesocket(s);

    if (n <= 0) {
        InterlockedExchange(&g_hookConnected, 0);
        return;
    }

    char stateStr[32];
    long remaining = 0;
    if (sscanf(buf, "STATUS %31s %ld", stateStr, &remaining) == 2) {
        int stateVal = HOOK_STATE_UNKNOWN;
        if (_stricmp(stateStr, "RUNNING") == 0) stateVal = HOOK_STATE_RUNNING;
        else if (_stricmp(stateStr, "PAUSED") == 0) stateVal = HOOK_STATE_PAUSED;
        else if (_stricmp(stateStr, "STOPPED") == 0) stateVal = HOOK_STATE_STOPPED;

        InterlockedExchange(&g_hookState, stateVal);
        InterlockedExchange(&g_hookRemainingSec, remaining);
        InterlockedExchange(&g_hookConnected, 1);
    } else {
        InterlockedExchange(&g_hookConnected, 0);
    }
}

static DWORD WINAPI StatusPollThread(LPVOID unused) {
    (void)unused;

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        LogMsg("StatusPollThread: WSAStartup failed - overlay will show 'connecting...' forever");
        return 0;
    }

    /* Loopback UDP socket for the "actively drawing" heartbeat to the
       desktop overlay. Created once; connectionless, so a sendto to an
       address nobody is listening on just silently no-ops - exactly the
       fire-and-forget behaviour we want. */
    SOCKET hbSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    struct sockaddr_in hbAddr;
    ZeroMemory(&hbAddr, sizeof(hbAddr));
    hbAddr.sin_family = AF_INET;
    hbAddr.sin_port = htons(HOOK_HEARTBEAT_PORT);
    hbAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    for (;;) {
        PollStatusOnce();

        /* If hkEndScene drew a frame within the last couple of seconds,
           tell the desktop overlay we're live so it stays hidden. */
        if (hbSock != INVALID_SOCKET) {
            DWORD lastDraw = (DWORD)InterlockedCompareExchange(&g_lastDrawTick, 0, 0);
            if (lastDraw != 0 && (GetTickCount() - lastDraw) < HOOK_DRAW_FRESH_MS) {
                sendto(hbSock, "HOOK_ALIVE", 10, 0,
                       (struct sockaddr *)&hbAddr, sizeof(hbAddr));
            }
        }

        Sleep(1000);
    }

    /* Not reached in normal operation - this thread lives for the life
       of the injected DLL, same as the rest of the hook's background
       work, so closesocket/WSACleanup here would never actually run. */
}

static void FormatStatusText(char *out, size_t outSize) {
    int connected = (int)InterlockedCompareExchange(&g_hookConnected, 0, 0);
    if (!connected) {
        snprintf(out, outSize, "TIMER: connecting...");
        return;
    }

    int state = (int)InterlockedCompareExchange(&g_hookState, 0, 0);
    long remaining = (long)InterlockedCompareExchange(&g_hookRemainingSec, 0, 0);
    if (remaining < 0) remaining = 0;

    long h = remaining / 3600, m = (remaining / 60) % 60, s = remaining % 60;

    switch (state) {
        case HOOK_STATE_RUNNING:
            snprintf(out, outSize, "TIMER  %02ld:%02ld:%02ld", h, m, s);
            break;
        case HOOK_STATE_PAUSED:
            snprintf(out, outSize, "PAUSED  %02ld:%02ld:%02ld", h, m, s);
            break;
        default:
            snprintf(out, outSize, "NO ACTIVE SESSION");
            break;
    }
}

static void UpdateOverlayTextIfNeeded(LPDIRECT3DDEVICE9 device) {
    /* Redraw only when the displayed text actually changes - same
       throttling principle as before (once/sec typically, from the poll
       thread's cadence), just driven by the real session state instead
       of local elapsed time now. */
    char buf[64];
    FormatStatusText(buf, sizeof(buf));

    if (strcmp(buf, g_lastRenderedText) == 0) return;
    strncpy(g_lastRenderedText, buf, sizeof(g_lastRenderedText) - 1);
    g_lastRenderedText[sizeof(g_lastRenderedText) - 1] = 0;

    RenderTextToOverlay(device, buf);
}

static void DrawOverlayQuad(LPDIRECT3DDEVICE9 device) {
    float x0 = 20.0f, y0 = 20.0f;
    float x1 = x0 + (float)OVERLAY_TEX_W;
    float y1 = y0 + (float)OVERLAY_TEX_H;
    D3DCOLOR white = D3DCOLOR_ARGB(255, 255, 255, 255);

    OverlayVertex verts[4] = {
        { x0, y0, 0.0f, 1.0f, white, 0.0f, 0.0f },
        { x1, y0, 0.0f, 1.0f, white, 1.0f, 0.0f },
        { x0, y1, 0.0f, 1.0f, white, 0.0f, 1.0f },
        { x1, y1, 0.0f, 1.0f, white, 1.0f, 1.0f },
    };

    DWORD oldLighting, oldZEnable, oldZWrite, oldAlphaBlend, oldCull, oldFog, oldAlphaTest, oldFVF;
    IDirect3DBaseTexture9 *oldTex = NULL;

    IDirect3DDevice9_GetRenderState(device, D3DRS_LIGHTING, &oldLighting);
    IDirect3DDevice9_GetRenderState(device, D3DRS_ZENABLE, &oldZEnable);
    IDirect3DDevice9_GetRenderState(device, D3DRS_ZWRITEENABLE, &oldZWrite);
    IDirect3DDevice9_GetRenderState(device, D3DRS_ALPHABLENDENABLE, &oldAlphaBlend);
    IDirect3DDevice9_GetRenderState(device, D3DRS_CULLMODE, &oldCull);
    IDirect3DDevice9_GetRenderState(device, D3DRS_FOGENABLE, &oldFog);
    IDirect3DDevice9_GetRenderState(device, D3DRS_ALPHATESTENABLE, &oldAlphaTest);
    IDirect3DDevice9_GetFVF(device, &oldFVF);
    IDirect3DDevice9_GetTexture(device, 0, &oldTex);

    IDirect3DDevice9_SetRenderState(device, D3DRS_LIGHTING, FALSE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ZENABLE, D3DZB_FALSE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ZWRITEENABLE, FALSE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ALPHABLENDENABLE, FALSE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_CULLMODE, D3DCULL_NONE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_FOGENABLE, FALSE);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ALPHATESTENABLE, FALSE);

    IDirect3DDevice9_SetTexture(device, 0, (IDirect3DBaseTexture9 *)g_overlayTex);
    IDirect3DDevice9_SetTextureStageState(device, 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    IDirect3DDevice9_SetTextureStageState(device, 0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    IDirect3DDevice9_SetTextureStageState(device, 1, D3DTSS_COLOROP, D3DTOP_DISABLE);
    IDirect3DDevice9_SetTextureStageState(device, 0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

    IDirect3DDevice9_SetFVF(device, OVERLAY_FVF);
    IDirect3DDevice9_DrawPrimitiveUP(device, D3DPT_TRIANGLESTRIP, 2, verts, sizeof(OverlayVertex));

    /* DrawPrimitiveUP can leave the stream source binding undefined per
       MSDN guidance - clear it so the game's own next draw isn't affected. */
    IDirect3DDevice9_SetStreamSource(device, 0, NULL, 0, 0);

    IDirect3DDevice9_SetTexture(device, 0, oldTex);
    if (oldTex) IDirect3DBaseTexture9_Release(oldTex);
    IDirect3DDevice9_SetFVF(device, oldFVF);
    IDirect3DDevice9_SetRenderState(device, D3DRS_LIGHTING, oldLighting);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ZENABLE, oldZEnable);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ZWRITEENABLE, oldZWrite);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ALPHABLENDENABLE, oldAlphaBlend);
    IDirect3DDevice9_SetRenderState(device, D3DRS_CULLMODE, oldCull);
    IDirect3DDevice9_SetRenderState(device, D3DRS_FOGENABLE, oldFog);
    IDirect3DDevice9_SetRenderState(device, D3DRS_ALPHATESTENABLE, oldAlphaTest);
}

/* Shared, idempotent cleanup - safe to call any number of times, only
   does anything the first time (checks for NULL). Releasing a D3D
   resource is always safe even while the device is lost/not-reset;
   Release() just decrements a refcount, it doesn't require a healthy
   device. Called proactively the moment TestCooperativeLevel reports
   ANY trouble, not just when Reset/ResetEx get called - because if the
   engine's actual recovery path is "destroy the old device and create
   a brand new one" rather than an in-place Reset, our texture holding a
   live reference to the OLD device would block it from ever truly being
   destroyed, which would block the adapter from becoming free for the
   new device - looking identical to "device reset failed" even though
   neither Reset nor ResetEx was ever involved. */
static void ReleaseOverlayResources(const char *reason) {
    if (g_overlayTex || g_overlaySysSurface) {
        LogMsgFmt("Releasing overlay D3DPOOL_DEFAULT resources (%s)", reason);
    }
    if (g_overlayTex) { IDirect3DTexture9_Release(g_overlayTex); g_overlayTex = NULL; }
    if (g_overlaySysSurface) { IDirect3DSurface9_Release(g_overlaySysSurface); g_overlaySysSurface = NULL; }
    g_overlayTexReady = 0;
    g_overlayTexFailed = 0;
    g_lastRenderedText[0] = 0; /* force a fresh redraw once resources are recreated */
}

/* ---------------------------- hook itself ---------------------------- */

static HRESULT WINAPI hkEndScene(LPDIRECT3DDEVICE9 device) {
    static int loggedFirstCall = 0;
    if (!loggedFirstCall) {
        LogMsg("hkEndScene called for the first time - inline hook is firing");
        loggedFirstCall = 1;
    }

    /* Do zero extra work while the device is lost/not-reset - this is
       exactly the window where any added latency risks starving the
       engine's own recovery loop (see the crash writeup above). */
    if (g_deviceOk) {
        if (EnsureOverlayTexture(device)) {
            UpdateOverlayTextIfNeeded(device);
            DrawOverlayQuad(device);
            /* Mark "drew a frame just now" for the heartbeat sender on
               the poll thread. Cheap atomic store, no I/O on this path. */
            InterlockedExchange(&g_lastDrawTick, (LONG)GetTickCount());
        }
    }

    return oEndScene(device);
}

/* Direct3D requires EVERY D3DPOOL_DEFAULT resource in the process to be
   released before Reset() can succeed - including ones the game itself
   didn't create. Our overlay texture is exactly such a resource, so
   without this hook, Reset() (triggered by alt-tab, the Windows key,
   resolution changes, etc) fails repeatedly and the game gives up and
   crashes with "Direct3D device reset failed after multiple attempts" -
   which is exactly what happened testing against C&C3. */
static HRESULT WINAPI hkReset(LPDIRECT3DDEVICE9 device, D3DPRESENT_PARAMETERS *pp) {
    LogMsg("Reset() intercepted");
    InterlockedExchange(&g_deviceOk, 0);
    ReleaseOverlayResources("Reset() intercepted");

    HRESULT hr = oReset(device, pp);
    if (SUCCEEDED(hr)) {
        InterlockedExchange(&g_deviceOk, 1);
        LogMsg("Reset() succeeded - overlay texture will be recreated lazily on next frame");
    } else {
        LogMsgFmt("Reset() still failed hr=0x%08lx even after releasing our resources "
                  "- likely unrelated to the overlay", hr);
    }
    return hr;
}

/* Same idea as hkReset, but for the D3D9Ex device recovery path. Some
   engines (and some driver/OS combos) use ResetEx instead of Reset for
   device-lost recovery - if the game's device is created via
   Direct3DCreate9Ex, this is the one that actually gets called, and a
   Reset-only hook would silently never fire, exactly what happened
   testing this against C&C3's actual crash. */
static HRESULT WINAPI hkResetEx(LPDIRECT3DDEVICE9 device, D3DPRESENT_PARAMETERS *pp, D3DDISPLAYMODEEX *mode) {
    LogMsg("ResetEx() intercepted");
    InterlockedExchange(&g_deviceOk, 0);
    ReleaseOverlayResources("ResetEx() intercepted");

    HRESULT hr = oResetEx(device, pp, mode);
    if (SUCCEEDED(hr)) {
        InterlockedExchange(&g_deviceOk, 1);
        LogMsg("ResetEx() succeeded - overlay texture will be recreated lazily on next frame");
    } else {
        LogMsgFmt("ResetEx() still failed hr=0x%08lx even after releasing our resources "
                  "- likely unrelated to the overlay", hr);
    }
    return hr;
}

/* Pure diagnostic - logs every device-lost/device-not-reset transition
   so we can see exactly what the engine is being told, without us
   changing any behavior here. Rate-limited to only log when the result
   changes, since this can be polled every frame by some engines. Also
   updates g_deviceOk, which hkEndScene uses to skip all overlay work
   while the device isn't in a known-good state. */
static HRESULT WINAPI hkTestCoopLevel(LPDIRECT3DDEVICE9 device) {
    static HRESULT lastLogged = S_OK + 1; /* sentinel that won't match a real HRESULT */
    HRESULT hr = oTestCoopLevel(device);

    InterlockedExchange(&g_deviceOk, (hr == S_OK) ? 1 : 0);

    if (hr != S_OK) {
        /* Release the instant we see ANY trouble, not just when/if
           Reset or ResetEx get called - see ReleaseOverlayResources'
           comment for why waiting for those isn't reliable enough. */
        ReleaseOverlayResources("TestCooperativeLevel reported non-OK status");
    }

    if (hr != lastLogged) {
        LogMsgFmt("TestCooperativeLevel() -> 0x%08lx", hr);
        lastLogged = hr;
    }
    return hr;
}

static int HookD3D9(void) {
    HWND dummyWnd = CreateWindowExA(0, "STATIC", "cafetimer_probe", WS_POPUP,
                                     0, 0, 1, 1, NULL, NULL, GetModuleHandle(NULL), NULL);
    if (!dummyWnd) { LogMsg("CreateWindowExA failed"); return 0; }

    D3DPRESENT_PARAMETERS pp;
    ZeroMemory(&pp, sizeof(pp));
    pp.Windowed = TRUE;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    pp.hDeviceWindow = dummyWnd;
    pp.BackBufferFormat = D3DFMT_UNKNOWN;

    /* Prefer creating our throwaway device via Direct3DCreate9Ex. This
       gives us a genuine IDirect3DDevice9Ex object with the FULL
       extended vtable (including ResetEx at index 132) allocated and
       valid to read. If we instead created a plain (non-Ex) device and
       just guessed that index 132 was still valid memory, that would be
       unsafe - reading/patching an out-of-bounds or garbage "function
       pointer" could crash the injected process. Falling back to the
       plain path below only skips the ResetEx hook, it never risks an
       invalid read. */
    void *d3d9exModule = GetModuleHandleA("d3d9.dll");
    typedef HRESULT (WINAPI *Direct3DCreate9Ex_t)(UINT, IDirect3D9Ex **);
    Direct3DCreate9Ex_t pDirect3DCreate9Ex = d3d9exModule
        ? (Direct3DCreate9Ex_t)(void *)GetProcAddress((HMODULE)d3d9exModule, "Direct3DCreate9Ex")
        : NULL;

    IDirect3D9Ex *d3dEx = NULL;
    IDirect3DDevice9Ex *deviceEx = NULL;
    IDirect3D9 *d3d = NULL;
    IDirect3DDevice9 *device = NULL;
    int isEx = 0;

    if (pDirect3DCreate9Ex && SUCCEEDED(pDirect3DCreate9Ex(D3D_SDK_VERSION, &d3dEx))) {
        HRESULT hr = IDirect3D9Ex_CreateDeviceEx(d3dEx, D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, dummyWnd,
                                                  D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, NULL, &deviceEx);
        if (SUCCEEDED(hr) && deviceEx) {
            isEx = 1;
            device = (IDirect3DDevice9 *)deviceEx;
            LogMsg("Dummy device created via Direct3DCreate9Ex (ResetEx hook available)");
        } else {
            LogMsgFmt("CreateDeviceEx failed hr=0x%lx, falling back to non-Ex", hr);
            IDirect3D9Ex_Release(d3dEx);
            d3dEx = NULL;
        }
    }

    if (!device) {
        d3d = Direct3DCreate9(D3D_SDK_VERSION);
        if (!d3d) { LogMsg("Direct3DCreate9 failed"); DestroyWindow(dummyWnd); return 0; }

        HRESULT hr = IDirect3D9_CreateDevice(d3d, D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, dummyWnd,
                                              D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, &device);
        if (FAILED(hr) || !device) {
            LogMsgFmt("CreateDevice failed hr=0x%lx", hr);
            IDirect3D9_Release(d3d);
            DestroyWindow(dummyWnd);
            return 0;
        }
        LogMsg("Dummy device created via Direct3DCreate9 (no ResetEx hook - not a D3D9Ex device)");
    }

    void **vtable = *(void ***)device;
    void *realEndScene = vtable[42];       /* IDirect3DDevice9::EndScene */
    void *realReset = vtable[16];          /* IDirect3DDevice9::Reset */
    void *realTestCoopLevel = vtable[3];   /* IDirect3DDevice9::TestCooperativeLevel */
    void *realResetEx = isEx ? vtable[132] : NULL; /* IDirect3DDevice9Ex::ResetEx - only valid on an Ex device */

    if (isEx) {
        IDirect3DDevice9Ex_Release(deviceEx);
        IDirect3D9Ex_Release(d3dEx);
    } else {
        IDirect3DDevice9_Release(device);
        IDirect3D9_Release(d3d);
    }
    DestroyWindow(dummyWnd);

    MH_STATUS mhStatus = MH_Initialize();
    if (mhStatus != MH_OK && mhStatus != MH_ERROR_ALREADY_INITIALIZED) {
        LogMsgFmt("MH_Initialize failed, status=%d", mhStatus);
        return 0;
    }

    mhStatus = MH_CreateHook(realEndScene, (void *)hkEndScene, (void **)&oEndScene);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_CreateHook(EndScene) failed, status=%d", mhStatus); return 0; }
    mhStatus = MH_EnableHook(realEndScene);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_EnableHook(EndScene) failed, status=%d", mhStatus); return 0; }

    mhStatus = MH_CreateHook(realReset, (void *)hkReset, (void **)&oReset);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_CreateHook(Reset) failed, status=%d", mhStatus); return 0; }
    mhStatus = MH_EnableHook(realReset);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_EnableHook(Reset) failed, status=%d", mhStatus); return 0; }

    mhStatus = MH_CreateHook(realTestCoopLevel, (void *)hkTestCoopLevel, (void **)&oTestCoopLevel);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_CreateHook(TestCooperativeLevel) failed, status=%d", mhStatus); return 0; }
    mhStatus = MH_EnableHook(realTestCoopLevel);
    if (mhStatus != MH_OK) { LogMsgFmt("MH_EnableHook(TestCooperativeLevel) failed, status=%d", mhStatus); return 0; }

    if (realResetEx) {
        mhStatus = MH_CreateHook(realResetEx, (void *)hkResetEx, (void **)&oResetEx);
        if (mhStatus != MH_OK) {
            LogMsgFmt("MH_CreateHook(ResetEx) failed, status=%d - continuing without it", mhStatus);
        } else {
            mhStatus = MH_EnableHook(realResetEx);
            if (mhStatus != MH_OK) {
                LogMsgFmt("MH_EnableHook(ResetEx) failed, status=%d - continuing without it", mhStatus);
            } else {
                LogMsg("ResetEx also hooked");
            }
        }
    }

    LogMsg("EndScene + Reset + TestCooperativeLevel inline-hooked successfully via MinHook");
    return 1;
}

static DWORD WINAPI MainThread(LPVOID hModule) {
    InitPaths((HMODULE)hModule);
    LogMsg("hook.dll attached, waiting for d3d9.dll");

    DWORD timeoutMs = ReadConfiguredTimeout();
    DWORD start = GetTickCount();

    while (GetModuleHandleA("d3d9.dll") == NULL) {
        if (GetTickCount() - start > timeoutMs) {
            LogMsg("Timed out waiting for d3d9.dll - self unloading");
            FlushLogToDisk();
            FreeLibraryAndExitThread((HMODULE)hModule, 0);
            return 0;
        }
        Sleep(200);
    }

    if (!HookD3D9()) {
        LogMsg("Hook install failed - self unloading");
        FlushLogToDisk();
        FreeLibraryAndExitThread((HMODULE)hModule, 0);
        return 0;
    }

    /* Only spawn this AFTER a successful hook install, never before -
       every path above this point can self-unload the DLL, and if that
       happened while this thread were still running, it would keep
       executing code inside now-unmapped memory (this thread's code
       lives in the DLL itself) - a guaranteed crash. Once hook install
       succeeds, the DLL stays resident for the life of the process, so
       there's no unload race to worry about from here on. */
    HANDLE pollThread = CreateThread(NULL, 0, StatusPollThread, NULL, 0, NULL);
    if (pollThread) {
        CloseHandle(pollThread);
    } else {
        LogMsg("Failed to start status-poll thread - overlay will show 'connecting...' forever");
    }

    return 0;
}

BOOL WINAPI DllMain(HINSTANCE hModule, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        HANDLE h = CreateThread(NULL, 0, MainThread, hModule, 0, NULL);
        if (h) CloseHandle(h);
    }
    return TRUE;
}
