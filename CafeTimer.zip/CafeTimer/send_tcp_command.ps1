# send_tcp_command.ps1
# Sends one command to Cafe Timer's TCP control server and prints
# the reply. Reusable building block for test scripts.
#
# Usage:  powershell -ExecutionPolicy Bypass -File send_tcp_command.ps1 -Command "GET_STATUS"

param(
    [Parameter(Mandatory=$true)][string]$Command,
    [string]$HostName = "localhost",
    [int]$Port = 47200
)

try {
    $client = New-Object System.Net.Sockets.TcpClient($HostName, $Port)
    $stream = $client.GetStream()
    $writer = New-Object System.IO.StreamWriter($stream)
    $writer.AutoFlush = $true
    $reader = New-Object System.IO.StreamReader($stream)

    $writer.WriteLine($Command)
    $reply = $reader.ReadLine()
    Write-Host $reply

    $client.Close()
} catch {
    Write-Host "ERR could not connect to $HostName`:$Port"
}
